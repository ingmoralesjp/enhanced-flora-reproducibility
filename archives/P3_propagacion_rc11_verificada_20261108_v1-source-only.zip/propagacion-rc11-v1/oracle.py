#!/usr/bin/env python3
"""Independent high-precision linear oracle and specified-normal CDF checks."""
import argparse
import csv
from decimal import Decimal, localcontext
import json
import math
from pathlib import Path
import statistics

import design
PI = Decimal("3.141592653589793238462643383279502884197169399375105820974944592307816406286")


def expected(row):
    """Compute a linear power ratio, independently of the native dB formula."""
    with localcontext() as context:
        context.prec=60
        d=lambda key: Decimal(str(row[key]))
        ten=Decimal(10)
        if row["friis"]:
            wavelength=d("reference_speed_mps")/d("reference_frequency_Hz")
            anchor=(wavelength/(4*PI*d("d0_m")))**2
            anchor*=ten**((d("tx_gain_dBi")+d("rx_gain_dBi")-d("system_loss_dB"))/10)
        else:
            anchor=ten**(-d("reference_loss_dB")/10)
        attenuation=anchor*(d("distance_m")/d("d0_m"))**(-d("gamma"))
        required_ratio=ten**((-Decimal(137)-d("tx_power_dBm"))/10)
        max_range=d("d0_m")*(anchor/required_ratio)**(Decimal(1)/d("gamma"))
        return float(attenuation),float(max_range),float(-10*attenuation.log10())


def csv_write(path,rows):
    with path.open("x",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(rows[0]));writer.writeheader();writer.writerows(rows)


def analyze(root):
    root=Path(root)
    stored=json.loads((root/"DESIGN.json").read_text())
    assert stored["cases"]==design.cases(), "Design changed after declaration"
    cases={r["case_id"]:r for r in stored["cases"]}
    comparisons=[]
    with (root/"native/seed-0/observed.csv").open() as stream: actual=list(csv.DictReader(stream))
    assert len(actual)==len(cases) and {r["case_id"] for r in actual}==set(cases)
    for observed in actual:
        row=cases[observed["case_id"]]
        rejected=observed["rejected"]=="1"
        if row["expected_rejection"]:
            ok=rejected and observed["error_phase"]==row["expected_error_phase"] and "positive" in observed["error"]
            comparisons.append(dict(case_id=row["case_id"],group=row["group"],quantity="input_rejection",expected=1,observed=int(rejected),absolute_error=int(not ok),relative_error="",tolerance=0,pass_=ok))
        else:
            assert not rejected, observed
            value,distance,_=expected(row)
            for quantity,ref,floor,unit in (("attenuation_ratio",value,design.ATTENUATION_ABSOLUTE_FLOOR,"ratio"),("range_m",distance,design.RANGE_ABSOLUTE_FLOOR_M,"m")):
                got=float(observed[quantity]); error=abs(got-ref); tol=max(floor,design.RELATIVE_TOLERANCE*abs(ref))
                comparisons.append(dict(case_id=row["case_id"],group=row["group"],quantity=quantity,expected=ref,observed=got,absolute_error=error,relative_error=error/abs(ref),tolerance=tol,pass_=math.isfinite(got) and error<=tol))
    # Only specified CDFs are tested. Neither mean nor sigma is estimated for acceptance.
    blocks=len(design.SEEDS)*2
    epsilon=math.sqrt(math.log(2*blocks/design.FAMILY_ALPHA)/(2*design.SAMPLES_PER_BLOCK))
    stochastic=[]
    statrow=dict(design.BASE,distance_m=15000.)
    base_loss=expected(statrow)[2]
    for seed in design.SEEDS:
        groups={"sigma_3_57":[],"sigma_7_08":[]}
        with (root/"native"/("seed-%d"%seed)/"samples.csv").open() as stream:
            for sample in csv.DictReader(stream):
                attenuation=float(sample["attenuation_ratio"])
                assert attenuation>0 and math.isfinite(attenuation)
                groups[sample["block"]].append(-10*math.log10(attenuation)-base_loss)
        for name,sigma in (("sigma_3_57",3.57),("sigma_7_08",7.08)):
            values=groups[name];n=len(values); assert n==design.SAMPLES_PER_BLOCK
            ordered=sorted(values)
            plus=max((i+1)/n-.5*(1+math.erf(x/(sigma*math.sqrt(2)))) for i,x in enumerate(ordered))
            minus=max(.5*(1+math.erf(x/(sigma*math.sqrt(2))))-i/n for i,x in enumerate(ordered))
            statistic=max(plus,minus)
            stochastic.append(dict(seed_set=seed,block=name,samples=n,expected_mean_dB=0.,observed_mean_dB=statistics.mean(values),expected_sigma_dB=sigma,observed_sample_sigma_dB=statistics.stdev(values),cdf_max_absolute_error=statistic,cdf_tolerance=epsilon,pass_=statistic<=epsilon))
    out=root/"analysis";out.mkdir(exist_ok=False)
    csv_write(out/"deterministic-comparison.csv",comparisons)
    csv_write(out/"shadowing-comparison.csv",stochastic)
    failure=[r for r in comparisons+stochastic if not r["pass_"]]
    numeric=[r for r in comparisons if r["quantity"]!="input_rejection"]
    status=dict(status="PASS" if not failure else "FAIL",deterministic_input_cases=len(cases),numeric_comparisons=len(numeric),input_rejection_cases=8,shadowing_blocks=len(stochastic),shadowing_samples=blocks*design.SAMPLES_PER_BLOCK,seeds=design.SEEDS,family_alpha=design.FAMILY_ALPHA,cdf_tolerance=epsilon,max_relative_error=max(r["relative_error"] for r in numeric),max_range_absolute_error_m=max(r["absolute_error"] for r in numeric if r["quantity"]=="range_m"),max_shadowing_cdf_error=max(r["cdf_max_absolute_error"] for r in stochastic),failures=failure,
        interpretation="Numerical conformance and seeded sampling check, not experimental channel calibration or validation of900 network runs; IID assumption is the sampling contract, not a claim proved about the PRNG")
    (out/"status.json").write_text(json.dumps(status,indent=2)+"\n")
    print(json.dumps(status,indent=2))
    return not failure


if __name__=="__main__":
    parser=argparse.ArgumentParser();parser.add_argument("root",type=Path)
    raise SystemExit(0 if analyze(parser.parse_args().root) else 1)
