#!/usr/bin/env python3
"""Independent numerical oracle: rational symbol arithmetic, linear noise and energy.

No simulator C++ function is called to obtain expected values.
"""
import argparse
import csv
from fractions import Fraction
import hashlib
import json
import math
from pathlib import Path

HERE=Path(__file__).resolve().parent
TABLE=(24,24,24,25,25,25,25,26,31,32,34,35,44)
# Independently transcribed receiver design contract; NOT a hardware validation.
SENS=(-124,-127,-130,-133,-135,-137)
CAPTURE=((1,-8,-9,-9,-9,-9),(-11,1,-11,-12,-13,-13),(-15,-13,1,-13,-14,-15),(-19,-18,-17,1,-17,-18),(-22,-22,-21,-20,1,-20),(-25,-25,-25,-24,-23,1))

def toa(sf,bw,n,cr,header=1,crc=1,de=-1):
    symbol=Fraction(2**sf,bw)
    if de==-1: de=int(symbol>=Fraction(16,1000))
    blocks=max(0,math.ceil(Fraction(8*n-4*sf+28+16*crc-20*(1-header),4*(sf-2*de))))
    return float((Fraction(49,4)+8+blocks*(cr+4))*symbol)

def current(db):
    rounded=math.floor(db+.5) if db>=0 else math.ceil(db-.5)
    return TABLE[max(2,min(14,rounded))-2]

def prepare(directory):
    directory.mkdir(parents=True,exist_ok=False)
    # Deterministic low/high stress and immediate attempts around release deadlines.
    rows=[]
    for t,sf,n in ((0,7,15),(.01,12,51),(10,9,37),(20,12,51),(21,7,15),(400,7,15)):
        rows.append((t,sf,n))
    for i in range(100): rows.append((500+i*.25,7+i%6,(15,37,51)[i%3]))
    # One attempt exactly at a release deadline, with the timer already inserted.
    rows.extend([(1000,7,15),(1000+toa(7,125000,15,4)/.01,7,15)])
    (directory/'scheduler-input.csv').write_text(''.join(f'{t:.12f} {sf} {n}\n' for t,sf,n in sorted(rows)))

def analyze(directory):
    results=[]
    for r in csv.DictReader((directory/'component-observed.csv').open()):
        g=r['group']; args=r['inputs_semicolon_delimited'].split(';'); observed=float(r['observed']); tol=0.
        if g=='F1':
            bw,nf=map(float,args); expected=1e-3*10**(-174/10)*bw*10**(nf/10);tol=expected*1e-12
        elif g in ('F3','F3_archived_default'): expected=toa(*map(int,args));tol=2e-12
        elif g=='F2_sensitivity': expected=SENS[int(args[0])-7];tol=1e-10
        elif g in ('F2_power','F2_SNIR'):
            delta=float(args[1]);expected=int(delta>=0)
            # Exact dB thresholds can round to either side when converted to linear.
            tol=1 if delta==0 else 0
        elif g=='F2_capture':
            sf,inter=map(int,args[:2]);diff=float(args[2]);expected=int(diff<CAPTURE[sf-7][inter-7])
        elif g=='F2_interference_SNIR':
            sf,inter=map(int,args[:2]);diff=float(args[2]);expected=1e-12/(1e-3*10**(-174/10)*125000*10**.6+1e-12*10**(-diff/10));tol=max(1e-12,expected*1e-10)
        elif g=='F2_joint_decision':
            sf,inter=map(int,args[:2]);diff=float(args[2]);snir=1e-12/(1e-3*10**(-174/10)*125000*10**.6+1e-12*10**(-diff/10))
            expected=int(diff>=CAPTURE[sf-7][inter-7] and 10*math.log10(snir)>=-7.5-2.5*(sf-7))
        elif g in ('F5_current','F5_legacy'): expected=current(float(args[0]));tol=1e-12
        elif g=='F5_energy': expected=3.3*current(float(args[0]))/1000*(float(args[2])-float(args[1]));tol=1e-12
        elif g=='identity':expected=100
        elif g=='MAC_progress':expected=0
        else:raise ValueError(g)
        results.append(dict(r,expected=expected,absolute_error=abs(observed-expected),tolerance=tol,pass_=abs(observed-expected)<=tol))
    with (directory/'component-comparison.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=results[0].keys());w.writeheader();w.writerows(results)
    # Independent chronological scheduler recurrence, integer picosecond deadlines.
    scheduler=[];free_ps=-1
    for r in csv.DictReader((directory/'scheduler-observed.csv').open()):
        t=float(r['time_s']);sf=int(r['SF']);n=int(r['bytes']); t_ps=round(t*1e12)
        # Attempts are preloaded at initialization; a same-time timer is
        # scheduled later. At equality, the request runs first and is rejected.
        expected=int(t_ps>free_ps); expected_toa=toa(sf,125000,n,4) if expected else 0
        if expected:free_ps=t_ps+round(expected_toa/.01*1e12)
        checks=[int(r['accepted'])==expected,abs(float(r['airtime_s'])-expected_toa)<2e-12,abs(float(r['holdoff_s'])-expected_toa/.01)<2e-10]
        scheduler.append(dict(r,expected_accepted=expected,expected_airtime_s=expected_toa,pass_=all(checks)))
    with (directory/'scheduler-comparison.csv').open('x',newline='') as f:
        w=csv.DictWriter(f,fieldnames=scheduler[0].keys());w.writeheader();w.writerows(scheduler)
    groups={g:{'cases':sum(r['group']==g for r in results),'failed':sum(r['group']==g and not r['pass_'] for r in results)} for g in sorted({r['group'] for r in results})}
    status={'status':'PASS' if all(r['pass_'] for r in results+scheduler) else 'FAIL','groups':groups,'scheduler_attempts':len(scheduler),'scheduler_failed':sum(not r['pass_'] for r in scheduler),'oracle_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),'failures':[r for r in results+scheduler if not r['pass_']][:20], 'threshold_boundary_rule':'Exact dB equality is reported, not assumed bit-exact after log/pow conversions; below/above sweeps require exact decisions.', 'scheduler_tie_rule':'Preloaded attempt runs before the duty-release timer at the identical timestamp and is rejected; no early acceptance is allowed.'}
    (directory/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(status,indent=2))
    return status['status']=='PASS'

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('mode',choices=['prepare','analyze']);p.add_argument('directory',type=Path);a=p.parse_args()
    if a.mode=='prepare':prepare(a.directory)
    elif not analyze(a.directory):raise SystemExit(1)
