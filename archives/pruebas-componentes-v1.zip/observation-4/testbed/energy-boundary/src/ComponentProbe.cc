// Native component probes. Expected values are computed by a separate Python oracle.
// SPDX-License-Identifier: LGPL-3.0-or-later
#include <fstream>
#include <iomanip>
#include <sstream>
#include "LoRaPhy/LoRaAirtimeCalculator.h"
#include "ArchivedAirtimeCalculator.h"
#include "LoRaPhy/LoRaAnalogModel.h"
#include "LoRaPhy/LoRaReceiver.h"
#include "LoRa/LoRaGWRadio.h"
#include "LoRaEnergyModules/LoRaEnergyConsumer.h"
#include "inet/physicallayer/wireless/common/signal/Interference.h"

namespace flora {
using namespace omnetpp;
using namespace inet;
using namespace inet::physicallayer;

// Controlled state input to the actual production energy consumer.
class CurrentTestRadio : public LoRaRadio {
public:
    RadioMode mode=RADIO_MODE_TRANSMITTER;
    ReceptionState rx=RECEPTION_STATE_RECEIVING;
    TransmissionState tx=TRANSMISSION_STATE_TRANSMITTING;
    RadioMode getRadioMode() const override { return mode; }
    ReceptionState getReceptionState() const override { return rx; }
    TransmissionState getTransmissionState() const override { return tx; }
};

class GivenSnir : public ScalarSnir {
    double value;
public:
    GivenSnir(const IReception *r, double db) : ScalarSnir(r, nullptr), value(std::pow(10., db/10.)) {}
    double getMin() const override { return value; }
};

class ComponentProbe : public cSimpleModule {
    std::ofstream out;
    void row(const std::string& group, const std::string& id, double observed,
             const std::string& input) {
        out << group << ',' << id << ',' << std::setprecision(17) << observed << ',' << input << '\n';
    }
    void initialize() override { scheduleAt(20, new cMessage("component-probe")); }
    void handleMessage(cMessage *msg) override {
        delete msg;
        out.open(par("outputFile").stringValue());
        out << "group,case,observed,inputs_semicolon_delimited\n";
        auto net = getParentModule();
        auto gwRadio = check_and_cast<LoRaGWRadio *>(net->getSubmodule("loRaGW",0)->getSubmodule("LoRaGWNic")->getSubmodule("radio"));
        auto rx = check_and_cast<LoRaReceiver *>(gwRadio->getSubmodule("receiver"));
        auto analog = check_and_cast<LoRaAnalogModel *>(net->getSubmodule("LoRaMedium")->getSubmodule("analogModel"));
        auto ec = check_and_cast<LoRaEnergyConsumer *>(net->getSubmodule("loRaNodes",0)->getSubmodule("LoRaNic")->getSubmodule("radio")->getSubmodule("energyConsumer"));
        auto mac = check_and_cast<LoRaMac *>(net->getSubmodule("loRaNodes",0)->getSubmodule("LoRaNic")->getSubmodule("mac"));
        // F1: exact -174 dBm/Hz convention in watts, versus independent linear oracle.
        for (int bw : {125000,250000,500000}) for (int nf : {0,3,6,9}) {
            analog->par("receiverNoiseFigureDb").setDoubleValue(nf);
            LoRaBandListening l(gwRadio,0,1,Coord(),Coord(),Hz(868100000),Hz(bw),7);
            row("F1",std::to_string(bw)+"_"+std::to_string(nf),analog->getBackgroundNoisePower(&l).get(),std::to_string(bw)+";"+std::to_string(nf));
        }
        analog->par("receiverNoiseFigureDb").setDoubleValue(6);
        // F3: exact archived defaults, plus explicitly labeled candidate-only CRC/DE overrides.
        for (int sf=7;sf<=12;++sf) for (int bw : {125000,250000,500000})
        for (int bytes : {0,1,15,20,37,51,255}) for(int cr=1;cr<=4;++cr)
        for(int header=0;header<=1;++header) for(int crc=0;crc<=1;++crc)
        for(int de : {-1,0,1}) {
            auto toa=calculateLoRaAirtime(sf,bw,bytes,cr,header,crc,de);
            std::string in=std::to_string(sf)+";"+std::to_string(bw)+";"+std::to_string(bytes)+";"+std::to_string(cr)+";"+std::to_string(header)+";"+std::to_string(crc)+";"+std::to_string(de);
            row("F3",in,toa.total().dbl(),in);
            if(crc==1 && de==-1)
                row("F3_archived_default",in,floraArchived::calculateLoRaAirtime(sf,bw,bytes,cr,header).total().dbl(),in);
        }
        // F2: native sensitivity, final SNIR gate and co-/inter-SF capture.
        rx->alohaChannelModel=false;
        for(int sf=7;sf<=12;++sf) {
            Packet pkt("desired"); auto frame=makeShared<LoRaMacFrame>(); frame->setChunkLength(B(37));
            frame->setReceiverAddress(MacAddress::BROADCAST_ADDRESS); pkt.insertAtFront(frame);
            LoRaTransmission tx(gwRadio,&pkt,0,1,.01,.01,.98,Coord(),Coord(),Quaternion(),Quaternion(),W(.001),Hz(868100000),sf,Hz(125000),4);
            LoRaReception base(gwRadio,&tx,0,1,Coord(),Coord(),Quaternion(),Quaternion(),Hz(868100000),Hz(125000),W(1e-12),sf,4);
            double sensDb=10*std::log10(rx->getSensitivity(&base).get()*1000);
            row("F2_sensitivity",std::to_string(sf),sensDb,std::to_string(sf));
            LoRaBandListening l(gwRadio,0,1,Coord(),Coord(),Hz(868100000),Hz(125000),sf);
            for(double delta : {-1.,-.01,0.,.01,1.}) {
                LoRaReception r(gwRadio,&tx,0,1,Coord(),Coord(),Quaternion(),Quaternion(),Hz(868100000),Hz(125000),W(std::pow(10.,(sensDb+delta-30)/10)),sf,4);
                row("F2_power",std::to_string(sf)+"_"+std::to_string(delta),rx->computeIsReceptionPossible(&l,&r,IRadioSignal::SIGNAL_PART_WHOLE),std::to_string(sf)+";"+std::to_string(delta));
                // Offsets around each specified SF gate; no expected decision is called here.
                GivenSnir snir(&r,-7.5-2.5*(sf-7)+delta);
                row("F2_SNIR",std::to_string(sf)+"_"+std::to_string(delta),rx->computeIsReceptionSuccessful(&l,&r,IRadioSignal::SIGNAL_PART_WHOLE,nullptr,&snir),std::to_string(sf)+";"+std::to_string(delta));
            }
            for(int interferingSf=7;interferingSf<=12;++interferingSf) for(double difference : {-30.,-20.,-10.,0.,2.,10.}) {
                Packet ipkt("interferer"); ipkt.insertAtFront(frame);
                LoRaTransmission itx(gwRadio,&ipkt,0,1,.01,.01,.98,Coord(),Coord(),Quaternion(),Quaternion(),W(.001),Hz(868100000),interferingSf,Hz(125000),4);
                LoRaReception desired(gwRadio,&tx,0,1,Coord(),Coord(),Quaternion(),Quaternion(),Hz(868100000),Hz(125000),W(1e-12),sf,4);
                LoRaReception interfering(gwRadio,&itx,0,1,Coord(),Coord(),Quaternion(),Quaternion(),Hz(868100000),Hz(125000),W(1e-12*std::pow(10.,-difference/10)),interferingSf,4);
                Interference inter(nullptr,new std::vector<const IReception *>{&interfering});
                std::string in=std::to_string(sf)+";"+std::to_string(interferingSf)+";"+std::to_string(difference);
                row("F2_capture",in,rx->isPacketCollided(&desired,IRadioSignal::SIGNAL_PART_WHOLE,&inter),in);
                // Check the analog noise includes a different SF, rather than treating it as zero.
                auto noise=analog->computeNoise(&l,&inter);
                auto snir=analog->computeSNIR(&desired,noise);
                row("F2_interference_SNIR",in,snir->getMin(),in);
                auto decision=rx->computeReceptionDecision(&l,&desired,IRadioSignal::SIGNAL_PART_WHOLE,&inter,snir);
                row("F2_joint_decision",in,decision->isReceptionSuccessful(),in);
                delete decision;
                delete snir; delete noise;
            }
        }
        // Identity regression deliberately reuses the same Packet address with placement new.
        alignas(Packet) unsigned char storage[sizeof(Packet)];
        auto before=rx->Total_rcvBelowSensitivity;
        for(int i=0;i<100;++i) {
            Packet *p=new(storage) Packet("address-reuse");
            auto frame=makeShared<LoRaMacFrame>();frame->setChunkLength(B(37)); p->insertAtFront(frame);
            LoRaTransmission tx(gwRadio,p,0,1,.01,.01,.98,Coord(),Coord(),Quaternion(),Quaternion(),W(.001),Hz(868100000),7,Hz(125000),4);
            LoRaReception r(gwRadio,&tx,0,1,Coord(),Coord(),Quaternion(),Quaternion(),Hz(868100000),Hz(125000),W(1e-20),7,4);
            LoRaBandListening l(gwRadio,0,1,Coord(),Coord(),Hz(868100000),Hz(125000),7);
            rx->computeIsReceptionPossible(&l,&r,IRadioSignal::SIGNAL_PART_WHOLE);
            rx->computeIsReceptionPossible(&l,&r,IRadioSignal::SIGNAL_PART_WHOLE);
            p->~Packet();
        }
        row("identity","100_distinct_200_callbacks",rx->Total_rcvBelowSensitivity-before,"100;200");
        // F5: table and nearest-integer mapping, and exact native integrator with warm-up clipping.
        for(double db=-1.;db<=17.;db+=.25) {
            auto ma=ec->getTxSupplyCurrent(std::lround(db));
            row("F5_current",std::to_string(db),ma,std::to_string(db));
            ec->lastEnergyUpdate=0; ec->completeRunEnergy=LoRaEnergyConsumer::EnergyBreakdown();
            ec->measurementEnergy=LoRaEnergyConsumer::EnergyBreakdown();
            ec->previousPower=LoRaEnergyConsumer::PowerBreakdown();
            ec->previousPower.tx=W(ec->supplyVoltage*ma/1000.);
            ec->integrateEnergyUntil(12);
            row("F5_energy",std::to_string(db),ec->measurementEnergy.total().get(),std::to_string(db)+";2;12");
            if(db>=2 && db<=14 && db==std::floor(db)) {
                double watts=math::dBmW2mW(db)/1000.;
                row("F5_legacy",std::to_string(db),ec->getLegacyTxSupplyCurrent(watts),std::to_string(db));
            }
        }
        // Complete radiated-watts -> dBm -> table -> supply-power path.
        auto realRadio=ec->radio;
        auto testRadio=new CurrentTestRadio();
        ec->radio=testRadio;
        for(double db=-1.;db<=17.;db+=.25) {
            testRadio->setCurrentTxPower(std::pow(10.,(db-30.)/10.));
            row("F5_native_power",std::to_string(db),ec->computePowerBreakdown().total().get(),std::to_string(db));
        }
        // State integration over [0,12], clipped at the 2-second warm-up.
        ec->lastEnergyUpdate=0; ec->completeRunEnergy=LoRaEnergyConsumer::EnergyBreakdown();
        ec->measurementEnergy=LoRaEnergyConsumer::EnergyBreakdown();
        testRadio->setCurrentTxPower(.01); // +10 dBm -> 31 mA
        testRadio->mode=IRadio::RADIO_MODE_TRANSMITTER;
        ec->previousPower=ec->computePowerBreakdown();ec->integrateEnergyUntil(1);
        testRadio->mode=IRadio::RADIO_MODE_RECEIVER;
        ec->previousPower=ec->computePowerBreakdown();ec->integrateEnergyUntil(4);
        testRadio->rx=IRadio::RECEPTION_STATE_IDLE;
        ec->previousPower=ec->computePowerBreakdown();ec->integrateEnergyUntil(7);
        testRadio->mode=IRadio::RADIO_MODE_SLEEP;
        ec->previousPower=ec->computePowerBreakdown();ec->integrateEnergyUntil(12);
        row("F5_native_state_energy","TX",ec->measurementEnergy.tx.get(),"0;1;2");
        row("F5_native_state_energy","RX",ec->measurementEnergy.rx.get(),"1;4;2");
        row("F5_native_state_energy","idle",ec->measurementEnergy.idle.get(),"4;7;2");
        row("F5_native_state_energy","sleep",ec->measurementEnergy.sleep.get(),"7;12;2");
        ec->radio=realRadio;delete testRadio;
        // Minimal native FSM reproductions, with every deadline already expired.
        for(int state : {LoRaMac::RECEIVING_1,LoRaMac::LISTENING_1,LoRaMac::RECEIVING_2}) {
            for(auto timer : {mac->endDelay_1,mac->endListening_1,mac->endDelay_2,mac->endListening_2}) {
                if(timer->isScheduled()) mac->cancelEvent(timer);
                timer->setArrival(mac->getId(),-1,SimTime(10));
            }
            mac->fsm.setState(state,"probe-expired");
            mac->handleWithFsm(state==LoRaMac::LISTENING_1 ? mac->endListening_2 : mac->droppedPacket);
            row("MAC_progress",std::to_string(state),mac->fsm.getState(),"expired_at_10;event_at_20;expected_idle");
        }
        out.close();
    }
};
Define_Module(ComponentProbe);

// Adapter calls the production GW MAC scheduler; only the external PHY sink is replaced.
class SchedulerProbe : public LoRaGWMac {
    std::ofstream out;
    int attempt=0;
    void initialize(int stage) override {
        if(stage) return;
        waitingForDC=false; enforceDutyCycle=true; gatewayDutyCycle=.01;
        airtimeModel="semtech"; dutyCycleModel="toa";
        GW_forwardedDown=GW_droppedDC=0; GW_downlinkTimeOnAir=GW_dutyCycleHoldoff=0;
        dutyCycleTimer=new cMessage("probe-duty-timer");
        out.open(par("outputFile").stringValue());
        out << "attempt,time_s,SF,bytes,accepted,holdoff_s,airtime_s\n";
        std::ifstream in(par("attempts").stringValue());
        double t; int sf,bytes;
        while(in>>t>>sf>>bytes) {
            auto p=new Packet("probe-downlink"); auto f=makeShared<LoRaMacFrame>();
            f->setChunkLength(B(bytes)); f->setLoRaSF(sf); f->setLoRaBW(Hz(125000)); f->setLoRaCR(4);
            f->setReceiverAddress(MacAddress(1)); p->insertAtFront(f);p->setKind(1);scheduleAt(t,p);
        }
    }
    void handleMessage(cMessage *msg) override {
        if(msg==dutyCycleTimer) { handleSelfMessage(msg); return; }
        auto p=check_and_cast<Packet *>(msg); auto f=p->peekAtFront<LoRaMacFrame>();
        int sf=f->getLoRaSF(), bytes=B(p->getDataLength()).get();
        auto accepted=GW_forwardedDown;double hold=GW_dutyCycleHoldoff,toa=GW_downlinkTimeOnAir;
        handleUpperMessage(msg);
        out << attempt++ << ',' << std::setprecision(17) << simTime().dbl() << ',' << sf << ',' << bytes << ',' << (GW_forwardedDown>accepted) << ',' << GW_dutyCycleHoldoff-hold << ',' << GW_downlinkTimeOnAir-toa << '\n';
    }
    void sendDown(cMessage *msg) override { delete msg; }
    void finish() override { out.close(); }
public:
    ~SchedulerProbe() override { cancelAndDelete(dutyCycleTimer); }
};
Define_Module(SchedulerProbe);
}
