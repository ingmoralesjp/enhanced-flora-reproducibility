"""Fixed verification design. Expected values never use native observed outputs."""
from copy import deepcopy

RELATIVE_TOLERANCE = 1e-11
ATTENUATION_ABSOLUTE_FLOOR = 1e-30
RANGE_ABSOLUTE_FLOOR_M = 1e-8
SEEDS = list(range(10))
SAMPLES_PER_BLOCK = 10000
FAMILY_ALPHA = 0.01
BASE = dict(d0_m=1000., gamma=2.32, sigma_dB=0., friis=1,
            reference_loss_dB=127.41, reference_frequency_Hz=868e6,
            reference_speed_mps=299792458., tx_gain_dBi=1., rx_gain_dBi=1.,
            system_loss_dB=0., distance_m=1000., argument_frequency_Hz=868e6,
            argument_speed_mps=299792458., tx_power_dBm=14.)


def cases():
    result = []
    def add(group, **kwargs):
        row = deepcopy(BASE); row.update(kwargs)
        row.update(case_id="case_%03d" % len(result), group=group,
                   expected_rejection=False, expected_error_phase="")
        result.append(row)
    for ratio in (.25, .5, 1, 2, 5, 15):
        add("distance", distance_m=1000*ratio)
    for gamma in (2., 2.32, 2.7, 3.5):
        for ratio in (1, 5, 15): add("exponent", gamma=gamma, distance_m=1000*ratio)
    for d0 in (40., 1000.):
        for frequency in (433e6, 868e6, 915e6):
            for ratio in (1, 5):
                add("reference_anchor", d0_m=d0, reference_frequency_Hz=frequency, distance_m=d0*ratio)
    for system in (0., 3., 10.):
        for gt,gr in ((0.,0.), (1.,1.), (2.,-1.)):
            for ratio in (1,15): add("gains_system", system_loss_dB=system, tx_gain_dBi=gt, rx_gain_dBi=gr, distance_m=1000*ratio)
    for frequency in (433e6,868e6,915e6): add("argument_frequency_fixed_anchor", argument_frequency_Hz=frequency, distance_m=5000.)
    for speed in (200e6,299792458.,300e6): add("argument_speed_fixed_anchor", argument_speed_mps=speed, distance_m=5000.)
    for reference in (80.,100.,127.41):
        for ratio in (1,2,15): add("explicit_reference", friis=0, reference_loss_dB=reference, distance_m=1000*ratio)
    for tx in (2.,8.,14.):
        for gamma in (2.,2.32,2.7):
            for friis in (0,1): add("range_inverse", tx_power_dBm=tx, gamma=gamma, friis=friis)
    for name, field, values, phase in (
        ("invalid_distance","distance_m",(0.,-1.),"computePathLoss"),
        ("invalid_frequency","argument_frequency_Hz",(0.,-1.),"computePathLoss"),
        ("invalid_speed","argument_speed_mps",(0.,-1.),"computePathLoss"),
        ("invalid_d0","d0_m",(0.,-1.),"initialize"),
    ):
        for value in values:
            add(name, **{field:value})
            result[-1].update(expected_rejection=True, expected_error_phase=phase)
    assert len(result)==89 and sum(not r["expected_rejection"] for r in result)==81
    return result


REFERENCES = [
    dict(title="ITU-R P.525-4: Calculation of free-space attenuation",url="https://www.itu.int/rec/R-REC-P.525-4-201908-S/en",use="Free-space attenuation reference; gains/system loss tracked separately"),
    dict(title="ns-3 official Model Library: Propagation",url="https://www2.nsnam.org/docs/models/html/propagation.html",use="Log-distance equation only, not implementation equivalence; ns-3's below-d0 convention differs"),
    dict(title="NIST Dataplot NORCDF reference",url="https://itl.nist.gov/div898/software/dataplot/refman2/ch8/norcdf.pdf",use="Normal CDF via erf; specified mean/sigma, not fitted from samples"),
    dict(title="Massart (1990), The Tight Constant in the Dvoretzky-Kiefer-Wolfowitz Inequality",url="https://doi.org/10.1214/aop/1176990746",use="Two-sided DKW bound; union bound across20 blocks under IID sampling assumption"),
]
