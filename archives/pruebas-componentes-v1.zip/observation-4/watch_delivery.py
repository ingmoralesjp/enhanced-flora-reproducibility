#!/usr/bin/env python3
"""Finish verification/package and queue the authorized sequential continuation."""
import argparse
from datetime import datetime,timezone
import fcntl
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

HERE=Path(__file__).resolve().parent

def atomic(path,data):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(data,indent=2)+'\n');temp.replace(path)

def notify(cli,thread,failed):
    receipt=HERE/'results/continuation-queued.json'
    if receipt.exists():return
    status=(HERE/'results/delivery-status.json').resolve()
    message=(
        'Aviso automático autorizado por Juan: revisión Enhanced FLoRa, numeral 4 '+
        ('requiere revisión. ' if failed else 'tiene entrega verificada. ')+
        f'Revisa {status} y observation-4/results/supervisor-status.json, final-verification.json y los recibos nativos. '
        'No detengas ni dupliques simulaciones. Juan autorizó completar ocho numerales uno por uno, con verificación y entrega antes del siguiente, sin aprobación intermedia. '
        'El numeral 3 ya fue entregado y notificado por Gmail. En el 4 verifica los barridos C++ contra referencias independientes, el fracaso esperado del reproductor original de MAC/identidad, los diez controles de identidad sin cambios primarios y las 33 ejecuciones nativas. '
        'El primer oráculo del runner esperaba conservar un timestamp posterior de tráfico; la verificación independiente documenta por qué no es un invariante y comprueba el episodio nativo RX2, junto con tres FSM de entrada fija. No confundas ese fallo del oráculo con fallo de simulación. '
        'Si el ZIP 4 y sus hashes están verificados, entrega su enlace en este chat, envía Gmail de avance a moralesalvarez@gmail.com y continúa con el numeral 5 (ocupación GW real por unión de intervalos RF; carga baja/alta; no ToA/holdoff como sustituto). '
        'Después continúa 6,7,8 en orden, según reviewer-response/STATUS.md y la solicitud íntegra. Conserva 1 GW, máximo1000 nodos y 10 repeticiones; sin validación experimental ni multi-GW. No mezcles la corrección MAC candidata con las 900 ejecuciones originales. '
        'Actualiza y compila el paper cuando haya evidencia, y notifica los avances relevantes o bloqueos por Gmail.'
    )
    atomic(receipt,{'state':'attempting','thread':thread})
    try:
        r=subprocess.run([str(cli),'queue','--thread',thread,'--message',message],stdout=subprocess.PIPE,stderr=subprocess.STDOUT,text=True,timeout=30)
        atomic(receipt,{'state':'queued' if r.returncode==0 else 'failed','returncode':r.returncode,'response':r.stdout[-2400:],'thread':thread,'note':'Queue acknowledgement alone does not prove the continuation executed.'})
    except Exception as exc:atomic(receipt,{'state':'uncertain','error':str(exc),'thread':thread})

def main():
    p=argparse.ArgumentParser();p.add_argument('--codex-cli',type=Path,required=True);p.add_argument('--thread',required=True);a=p.parse_args()
    lock=(HERE/'results/supervisor.lock').open('a')
    try:fcntl.flock(lock,fcntl.LOCK_EX|fcntl.LOCK_NB)
    except BlockingIOError:raise SystemExit('Existing item-4 supervisor holds lock')
    statusfile=HERE/'results/supervisor-status.json'
    try:
        while True:
            native=json.loads((HERE/'results/regressions-v1/status.json').read_text())
            state={'status':'WAITING_EXTENDED_NATIVE_REGRESSION','native_status':native['status'],'accepted':native.get('accepted',sum(r['status']=='PASS' for r in native.get('done',{}).values())),'total':33,'pid':os.getpid(),'updated_utc':datetime.now(timezone.utc).isoformat(),'worker_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
            atomic(statusfile,state)
            if native['status']!='RUNNING':break
            time.sleep(30)
        with (HERE/'results/finalize.log').open('x') as stream:
            r=subprocess.run([sys.executable,str(HERE/'finalize_delivery.py')],stdout=stream,stderr=subprocess.STDOUT)
        if r.returncode:raise RuntimeError('Independent verification/package gate failed; see finalize.log')
        delivery=json.loads((HERE/'results/delivery-status.json').read_text())
        if delivery['status']!='DELIVERY_READY':raise RuntimeError('Delivery is not ready')
        atomic(statusfile,{'status':'DELIVERY_READY','archive':delivery['archive'],'sha256':delivery['sha256'],'pid':os.getpid(),'updated_utc':datetime.now(timezone.utc).isoformat()})
        notify(a.codex_cli,a.thread,False)
    except Exception as exc:
        atomic(statusfile,{'status':'REQUIRES_REVIEW','error':str(exc),'pid':os.getpid(),'updated_utc':datetime.now(timezone.utc).isoformat()})
        notify(a.codex_cli,a.thread,True)
        raise

if __name__=='__main__':main()
