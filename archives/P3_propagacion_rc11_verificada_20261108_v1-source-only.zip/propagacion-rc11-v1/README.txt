Enhanced FLoRa — P3 propagation verification 20261108-v1

1. CHECK AND REANALYZE (no build, standard library only)
From this extracted directory, using Python >=3.9:
  python3 verify_package.py --root .
This checks hashes, the unchanged original sources, acceptance counts, and
reanalyzes a disposable copy of the native raw outputs. It writes only
PACKAGE_VERIFICATION.json here; archived analysis is never overwritten.

2. BUILD AND EXECUTE (choose installed dependency paths)
The exact rc11 source archive is included under source/. Dependencies and
their source/build instructions are in the P1 compendium. Recorded toolchain:
OMNeT++6.0pre11, INET4.3.2, clang++10.0.0, C++14; see compiler-version.txt,
receipt.json and P1 environment manifests. Do not infer byte-identical
executables from different compilers or dependency versions.

  python3 run_verification.py \
    --source-archive source/enhanced-flora-0.2.0-dev-rc11.tar.gz \
    --omnet-dir /YOUR/OMNETPP \
    --inet-dir /YOUR/INET \
    --output /YOUR/NEW_NONEXISTENT_RESULT_DIRECTORY

Use the matching prebuilt dependencies, not personal paths from the old logs.
The runner invokes clang++, compiles only a private native test library, and
runs 10 small component tests (seed-sets0–9). It refuses an existing output
directory and never builds the shared project or replaces libINET/libflora.
Optional --protected-root can additionally hash a complete evidence tree.

3. OPTIONAL ANALYZER CONTROLS (no simulator)
  python3 test_oracle.py results/native-v2 /YOUR/NEW_CONTROL_REPORT.json
The controlled corruptions occur only in disposable copies. Expected FAIL
from those copies is the successful negative-control result.

REPORT.pdf/txt: design, interpretation, caveats and references.
RESPONSE_TO_P3.txt: text for the reviewer response letter.
DESIGN.json and receipt.json: declared cases, criteria, commands and hashes.
results/native-v2/native: raw inputs/outputs, per-seed INI and simulator logs.
results/native-v2/analysis: expected/observed/error/tolerance tables and status.
setup-attempt-native-v1: failed adapter setup, retained for audit; zero tests
executed. It is not a numerical failure of the propagation implementation.
The compiled plugin in work/build is a test artifact, not the historical
library used in the 900 runs. Original licenses remain in source/*.tar.gz;
the new adapter is LGPL-3.0-or-later. No paper source has been edited.
