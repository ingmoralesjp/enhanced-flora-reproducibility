#!/usr/bin/env python3
"""Sanity and negative controls on disposable copies, never production inputs."""
import csv
import json
import math
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile

import design
import oracle


def main():
    original = Path(sys.argv[1]).resolve()
    output = Path(sys.argv[2]).resolve()
    assert not output.exists(), "Choose a fresh report path"
    checks = []
    def check(name, passed, detail):
        checks.append(dict(test=name, passed=bool(passed), detail=detail))
    base = dict(design.BASE, friis=0, reference_loss_dB=100., gamma=2., tx_power_dBm=3.)
    attenuation, distance, _ = oracle.expected(base)
    check("analytic_reference_anchor", attenuation == 1e-10 and distance == 100000.,
          "100 dB anchor, gamma2, 1000m, 3dBm and -137dBm -> ratio1e-10, range100000m")
    reference = oracle.expected(design.BASE)[0]
    unity_gains = oracle.expected(dict(design.BASE, tx_gain_dBi=0., rx_gain_dBi=0.))[0]
    check("two_dBi_not_linear_unity", math.isclose(reference / unity_gains, 10**.2, rel_tol=1e-14),
          "1dBi+1dBi increases received power by 2dB")
    lossy = oracle.expected(dict(design.BASE, system_loss_dB=3.))[0]
    check("system_loss_conversion", math.isclose(lossy/reference, 10**-.3, rel_tol=1e-14),
          "3dB reduces linear power ratio by 10^-0.3")
    farther = oracle.expected(dict(design.BASE, distance_m=4000.))[0]
    check("distance_power_law", math.isclose(farther/reference, 4**-2.32, rel_tol=1e-14),
          "Four times distance scales power ratio by 4^-gamma")
    for mutation in ("attenuation_x2", "shadowing_shift_10dB"):
        with tempfile.TemporaryDirectory(prefix="p3-oracle-negative-") as directory:
            root = Path(directory)
            shutil.copy2(original/"DESIGN.json", root/"DESIGN.json")
            shutil.copytree(original/"native", root/"native")
            target = root/"native/seed-0"/("observed.csv" if mutation == "attenuation_x2" else "samples.csv")
            with target.open() as stream:
                reader = csv.DictReader(stream); fields = reader.fieldnames; rows = list(reader)
            if mutation == "attenuation_x2":
                rows[0]["attenuation_ratio"] = str(2*float(rows[0]["attenuation_ratio"]))
            else:
                for row in rows:
                    row["attenuation_ratio"] = str(float(row["attenuation_ratio"])/10.)
            with target.open("w", newline="") as stream:
                writer=csv.DictWriter(stream, fieldnames=fields); writer.writeheader(); writer.writerows(rows)
            process = subprocess.run([sys.executable, str(Path(oracle.__file__)), str(root)], capture_output=True, text=True)
            result = json.loads((root/"analysis/status.json").read_text())
            check(mutation, process.returncode == 1 and result["status"] == "FAIL" and bool(result["failures"]),
                  "Analyzer rejects deliberately corrupted copied output; original output not edited")
    status = dict(status="PASS" if all(r["passed"] for r in checks) else "FAIL", checks=checks,
                  note="Post-execution analyzer controls, not changes to predeclared acceptance criteria or native model")
    output.write_text(json.dumps(status, indent=2)+"\n")
    print(json.dumps(status, indent=2))
    assert status["status"] == "PASS"


if __name__ == "__main__":
    main()
