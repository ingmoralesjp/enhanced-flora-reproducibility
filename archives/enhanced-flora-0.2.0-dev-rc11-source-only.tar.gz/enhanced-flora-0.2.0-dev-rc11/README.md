# Enhanced FLoRa release candidate

Enhanced FLoRa is an audited extension of FLoRa 1.1 for reproducible LoRaWAN
simulation. The distribution preserves the upstream LGPL-3.0 license and
attribution and provides corrected cross-layer behavior, tests, reproducible
campaign tooling, paper sources, and compact evidence.

This is a development package, not an official upstream FLoRa release.

## Included

- clean active simulator source under `src/`;
- canonical simulation configuration under `simulations/`;
- validation, resumable execution, extraction, and paper-generation tools;
- platform paper and supporting audit/ablation documents;
- corrected F0--F5 run-level/summary data and 900 accepted-run receipts;
- official-FLoRa-1.1 compact run-level data, eight failure identities, source audit, and isolated compatibility patches;
- `MANIFEST.sha256` covering every packaged file except the manifest itself.

## External dependencies

The current Enhanced campaign provenance uses OMNeT++ 6.0pre11 and the INET
build recorded by the project. The official FLoRa 1.1 reference is separate and
uses OMNeT++ 6.0 final with INET 4.4.0. These stacks must not be silently mixed.

## Raw data

The full local result tree is about 54 GB and is not included here. This
compendium includes accepted-run receipts and all summarized data used by the
paper. The separate local corrected archive contains the 900 accepted scalars
and their 900 completion logs. Its file-level inventory and SHA-256 checksum
are in `evidence/raw-corrected/`; the approximately 2.5-GB archive itself is
not included and has not been deposited publicly. Official FLoRa 1.1 raw
output is a different dataset and is not merged into this archive.

## Verify and regenerate

From the distribution root, verify its SHA-256 manifest, frozen source
identity, matrix dimensions, and official acceptance/failure map:

`python3 tools/verify_corrected_release.py .`

To rebuild every generated platform-paper table and figure and compile the
manuscript from the packaged compact data, choose a new output directory:

`python3 tools/regenerate_platform_paper.py --output-dir /tmp/enhanced-paper-check-unique`

The command refuses to overwrite an existing directory. PDF image metadata
can change on regeneration; the numerical CSV and LaTeX tables must match
exactly. A clean source build and short simulator smoke test passed. The
diagnostic MAC assertion also passed ten short F0--F5/control/population
paths. Re-run it against a built INET tree with:

`python3 tests/run_mac_one_send_regression.py . --inet-dir /path/to/inet --output-dir /tmp/unique-mac-check`

The assertion is applied only to a disposable copy of the frozen source.
This is not a full-horizon proof. Public release still needs final attribution
and repository metadata review plus a separately hashed raw-scalar archive.

## Re-run without changing the paper evidence

After a clean build, use `tools/rerun_corrected_release.py` with an output
directory outside this distribution. Its default horizon is 12 days and it
supports the paper's 100--1000-device, five-repetition F0--F5 matrix. Use
`--dry-run` to inspect selection and `--resume` to skip hash-verified accepted
jobs after interruption. Rebuilt binaries receive a new provenance identity;
do not pool their outputs with the frozen 900 runs without equivalence tests.
The historical runner is retained as provenance and targets its original
working result tree; do not invoke it inside this compact distribution.

## Scientific scope

The package evaluates one-gateway networks. Multi-gateway experiments and field
validation are outside the stated scope. ADR algorithm proposals are separate
from the platform corrections and should cite their own experimental papers.
