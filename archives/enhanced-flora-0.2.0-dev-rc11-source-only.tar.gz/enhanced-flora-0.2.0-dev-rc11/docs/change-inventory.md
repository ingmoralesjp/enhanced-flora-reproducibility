# Enhanced FLoRa change and evidence inventory

This inventory is the canonical map from official FLoRa 1.1 behavior to the
Enhanced FLoRa implementation, validation evidence, paper claim, and release
artifact. A correction is not called validated merely because it compiles.

| ID | Area | Official FLoRa 1.1 / inherited behavior | Enhanced FLoRa behavior | Evidence now | Release evidence required |
|---|---|---|---|---|---|
| EF-01 | Source control | One upstream implementation, but later research trees accumulated alternative active and commented paths | One clean active source path; historical variants excluded from builds | Source audit | Clean source manifest and build test |
| EF-02 | Propagation | Log-normal model fixes `PL(d0)=127.41 dB` independently of configured frequency and reference distance | Optional Friis-derived anchor at configured `d0`, frequency, gains, and system loss | Formula audit; integration tests; prior publication lineage | Unit vector and source-to-equation trace |
| EF-03 | Channels | Experiment-dependent single/fixed channel behavior | Configurable EU868 channel set, including the three mandatory default uplink channels and balanced multi-channel use | Integration and 900-run campaign | Deterministic allocation regression |
| EF-04 | ADR recovery | Data rate backs off without first restoring maximum transmit power | Restore transmit power before increasing SF after ADR delay | Source and integration audit | State-machine regression |
| EF-05 | RX windows and synchronization | An unconditional reception-state callback can re-enter the MAC while it enters `TRANSMIT`; later research code queued the duplicated frame at the radio | Correct RX2 decapsulation; admit reception callbacks only in listening states; keep radio overlap fail-fast rather than queueing a duplicate | Same-frame/same-event diagnosis; failing seed repaired; short paths pass; four-pair impact screen | One-send invariant and regenerated campaign evidence |
| EF-06 | Delivery accounting | Gateway copies and auxiliary frames can contaminate application delivery | Unique delivery by transmitter/sequence; raw copies and auxiliary traffic separated | Invariants and integration tests | `0 <= PDR <= 1` and duplicate-injection test |
| EF-07 | Warm-up | Sent and received populations can use different temporal boundaries | Original uplink timestamp defines both numerator and denominator | Invariant audit; campaign extraction checks | Boundary-vector regression |
| EF-08 | Loss diagnosis | Failure mechanisms are conflated | Sensitivity, collision/not-attempted, low-SNR, half-duplex, and abort causes recorded separately | Instrumented campaign | Conservation identity over all outcomes |
| EF-09 | Noise | Sensitivity-table values also act as background noise | Thermal `kTB` noise plus receiver noise figure; sensitivity remains separate | Formula audit; F1 ablation | Known-value regression |
| EF-10 | Reception | No independent SF-specific required-SNR success gate | Minimum packet SNIR checked against SF-specific requirement | Formula audit; F2 ablation | Threshold boundary vectors |
| EF-11 | Time on air | Hard-coded 20-byte ED/15-byte GW approximation; actual frame composition not represented | Shared Semtech-style ToA over actual on-air bytes, including low-data-rate optimization | Unit tests; F3 ablation | Published calculator vectors and packet-size tests |
| EF-12 | Gateway duty cycle | Fixed SF-dependent holdoff constants | Holdoff derived from actual downlink airtime and configured duty fraction | Unit/integration tests; F4 ablation | Budget invariant and long-run fraction test |
| EF-13 | Energy interface | Energy/power signal semantics and units are ambiguous | Instantaneous power in watts and cumulative energy in joules use distinct signals | Dimensional audit | Signal-unit regression |
| EF-14 | Energy integration | Initial/final intervals and sleep energy can be omitted | Every previous state is integrated through transitions and simulation end | Component tests | Energy-balance identity |
| EF-15 | Energy endpoints | One full-run total is not aligned with the delivery window | Full-run and post-warm-up totals plus TX/RX/idle/sleep components | F5 ablation and scalar audit | Sum-of-components regression |
| EF-16 | Mobility | Node composition and app cast are stationary-specific | `IMobility` supports selectable stationary and RandomWaypoint behavior without source edits | Static/mobile/mixed campaign | Fixed-seed trajectory smoke tests |
| EF-17 | Reproducibility | Large INI files and labels are insufficient proof of executed behavior | Named configs, identity scalars, accepted markers, resumable runners, manifests, and audited extraction | 900/900 accepted F0--F5 runs | Fresh-machine reproduction workflow |

## Evidence interpretation

- The F0--F5 experiment is a cumulative causal ablation inside the Enhanced
  lineage. F0 is **not** stock FLoRa 1.1.
- The official comparison is a stack-level external reference. It cannot assign
  an observed PDR difference to one change because propagation, timing, traffic
  pacing, reception, duty cycle, metrics, and toolchain differ together.
- The guarded official-lineage fork completes the preserved failing seed but
  materially changes all three equivalence controls. It is a semantic
  correction and is never used to fill or relabel the incomplete official
  matrix.
- ADR algorithm novelty and algorithm rankings belong to separate manuscripts.

## Current quantitative evidence

The completed cumulative campaign contains six stages, three populations,
ten node counts, and five paired repetitions (900 runs). It belongs to the
`0.1.0-dev` source snapshot, before the causal MAC reentry correction. Its
within-version cumulative contrasts remain audited evidence, but it is not
silently presented as validation of the corrected release source. At 1,000 devices, the
existing audited manuscript reports that physical ToA reduces PDR by roughly
0.99--1.00 percentage points and adds 3.66--3.69 mJ per successful delivery;
airtime-based gateway scheduling reduces observed gateway duty fraction from
about 11.5% to 1% and increases downlink rejection by 25.1--26.7 points. The
complete correction path changes PDR by 1.16--1.20 points and energy per success
by 9.8--11.5% relative to the recovered Enhanced-lineage baseline.

The causal MAC correction was then screened in four exact 12-day source-version
pairs. Corrected-minus-`0.1.0-dev` PDR is -17.23 pp (F0, 100 EDs), -33.50 pp
(F5, 100 EDs), -51.20 pp (F0, 400 EDs), and -67.80 pp (F5, 400 EDs). Energy per
success increases by 4.95--7.66 mJ. Because only one paired repetition was run
per cell, this is magnitude-screening evidence, not inferential evidence. Its
role is to demonstrate materiality and require regeneration of the complete
corrected-source matrix.
