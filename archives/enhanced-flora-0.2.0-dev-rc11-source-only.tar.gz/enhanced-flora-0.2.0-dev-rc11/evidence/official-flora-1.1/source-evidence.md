# Source evidence for the simulator boundary

This index connects the comparison claims to immutable source lines. Paths
beginning with `upstream/flora` belong to official FLoRa 1.1.0. Paths
beginning with `../risk-paper-v1/faithful` belong to the frozen corrected-v1
release. The official campaign manifest hashes the former; the parent
`FREEZE-MANIFEST.sha256` hashes the latter.

| Topic | Official FLoRa 1.1 evidence | Corrected-v1 evidence | Supported statement |
|---|---|---|---|
| Stationary versus mobile node | `upstream/flora/src/LoraNode/LoRaNode.ned:18,24-40`; `upstream/flora/src/LoRaApp/SimpleLoRaApp.cc:17,35,100` | `../risk-paper-v1/faithful/src/LoraNode/LoRaNode.ned:18-20,31,43`; app accesses `IMobility` at `SimpleLoRaApp.cc:140-148` | Stock FLoRa 1.1 is stationary in this node/app composition; corrected-v1 can select RandomWaypoint. |
| Path-loss anchor | `upstream/flora/src/LoRaPhy/LoRaLogNormalShadowing.cc:47-52` fixes 127.41 dB | `../risk-paper-v1/faithful/src/LoRaPhy/LoRaLogNormalShadowing.cc:37-45,59-71` computes Friis at configured `d0` | Supplying the same `d0`, gamma, and sigma does not equalize the channel. At 1 km and 868 MHz the anchors differ by about 36.20 dB. |
| Uplink/downlink airtime | `upstream/flora/src/LoRaPhy/LoRaTransmitter.cc:66-80` hard-codes 20 B for ED and 15 B for GW | `../risk-paper-v1/faithful/src/LoRaPhy/LoRaTransmitter.cc:51-63` derives bytes from the on-air packet and uses the Semtech-style calculator | Application `dataSize=20B` has different airtime semantics across stacks. |
| ED packet timing | `upstream/flora/src/LoRaApp/SimpleLoRaApp.cc:119-134` redraws the exponential sample until it exceeds an SF-specific threshold | `../risk-paper-v1/faithful/src/LoRaApp/SimpleLoRaApp.cc:151-158` schedules the common draw directly | The official offered process becomes SF-dependent; corrected-v1 has no ED duty queue. |
| GW duty holdoff | `upstream/flora/src/LoRa/LoRaGWMac.cc:120-128` uses fixed SF constants | `../risk-paper-v1/faithful/src/LoRa/LoRaGWMac.cc:139-164` derives holdoff from actual downlink ToA and configured duty fraction | Gateway deaf time and command acceptance are not interchangeable. |
| Noise and decode gate | `upstream/flora/src/LoRaPhy/LoRaAnalogModel.cc:34-82` uses sensitivity-table values as noise; `LoRaReceiver.cc:254-258` returns success without a separate SNR gate | `../risk-paper-v1/faithful/src/LoRaPhy/LoRaAnalogModel.cc:56-69` uses thermal noise plus noise figure; `LoRaReceiver.cc:396-413` enforces SF-specific required SNR | Reception changes are PHY-stack effects, not evidence that the ADR rule itself improved. |
| Legacy ADR high-level rule | `upstream/flora/src/LoRa/NetworkServerApp.cc:318-347` keeps a 20-frame window and selects max/avg; experiment INI sets max and 15 dB | `../risk-paper-v1/faithful/src/LoRa/NetworkServerApp.cc:448-486` keeps the historical max/avg, margin, SF-first and 3-dB power-step policy | The high-level Legacy policy is comparable, while its surrounding execution semantics differ. |
| Energy window | `upstream/flora/src/LoRaEnergyModules/LoRaEnergyConsumer.cc:62-71,151-155` accumulates a single full-run total | `../risk-paper-v1/faithful/src/LoRaEnergyModules/LoRaEnergyConsumer.cc:180-204,217-230` separates complete-run and post-warm-up energy | Native official energy is diagnostic only and cannot be pooled with the corrected endpoint. |
| Position within 20 application bytes | Official reference has `dataSize=20B` at `experiment/official-legacy.ini:32-37` and carries no candidate position field | Parent common config has 20 B and an 8-B position allocation at `common.ini:17,33-35`; candidate configs set measurement data to 12 B at `screen.ini:30-40`; packet construction adds those 8 B at `SimpleLoRaApp.cc:211-212` | The candidate sends 12 measurement bytes plus 8 coordinate bytes, not 20+8 application bytes. |

## Interpretation

The official reference is deliberately source-faithful, not physics-matched.
Its PDR identifies the behavior of the released stack under the closest
matchable static high-level scenario. Numerical separation from corrected-v1
must be attributed first to the complete implementation boundary. It cannot
be used as a causal estimate of an ADR change.
