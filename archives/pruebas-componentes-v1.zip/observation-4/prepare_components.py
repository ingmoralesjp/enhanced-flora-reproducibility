#!/usr/bin/env python3
"""Create a separately versioned component/liveness candidate, never edit old campaigns."""
import argparse
import difflib
import hashlib
import json
from pathlib import Path
import shutil

HERE = Path(__file__).resolve().parent
SOURCE = HERE.parent / 'observation-3/testbed/flora'
OUT = HERE / 'testbed/flora'

def main():
    global SOURCE, OUT
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--source-root',type=Path,default=SOURCE)
    parser.add_argument('--output',type=Path,default=OUT)
    args=parser.parse_args();SOURCE=args.source_root.resolve();OUT=args.output.resolve()
    if OUT.exists():
        raise SystemExit('Refusing to overwrite the existing candidate')
    OUT.mkdir(parents=True)
    shutil.copy2(SOURCE/'Makefile', OUT/'Makefile')
    shutil.copytree(SOURCE/'src', OUT/'src', ignore=shutil.ignore_patterns('Makefile', '*.so', '*.o', '*.d', 'out'))
    shutil.copytree(SOURCE/'simulations', OUT/'simulations')
    patch = []
    parent_hashes = {}
    def edit(name, replacements):
        f = OUT/name
        before = f.read_text(); after = before
        parent_hashes[name] = hashlib.sha256((SOURCE/name).read_bytes()).hexdigest()
        for a,b in replacements:
            if after.count(a) != 1: raise ValueError((name,a))
            after = after.replace(a,b,1)
        f.write_text(after)
        patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile=name,tofile=name))
    # Stable identity applies only to diagnostic counting, never reception decisions.
    edit('src/LoRaPhy/LoRaReceiver.h', [
        ('class LoRaReceiver : public FlatReceiverBase\n\n{','class LoRaReceiver : public FlatReceiverBase\n\n{\n    friend class ComponentProbe;'),
        ('std::set<const Packet*> flaggedBelowSens','std::set<int64_t> flaggedBelowSens'),
        ('std::set<const Packet*> collidedPackets','std::set<int64_t> collidedPackets'),
    ])
    edit('src/LoRaPhy/LoRaReceiver.cc', [
        ('const Packet* pkt = reception->getTransmission()->getPacket();\n                // Packet already', 'const int64_t pkt = reception->getTransmission()->getPacket()->getTreeId();\n                // Stable identity, independent of allocator reuse. Packet already'),
        ('const Packet* pkt = reception->getTransmission()->getPacket();\n        collidedPackets.insert(pkt);','const int64_t pkt = reception->getTransmission()->getPacket()->getTreeId();\n        collidedPackets.insert(pkt);'),
    ])
    edit('src/LoRaEnergyModules/LoRaEnergyConsumer.h', [
        ('class LoRaEnergyConsumer : public inet::physicallayer::StateBasedEpEnergyConsumer\n{','class LoRaEnergyConsumer : public inet::physicallayer::StateBasedEpEnergyConsumer\n{\n    friend class ComponentProbe;')])
    edit('src/LoRa/LoRaMac.h', [
        ('class LoRaMac : public MacProtocolBase\n{','class LoRaMac : public MacProtocolBase\n{\n    friend class ComponentProbe;')])
    replacements = []
    for state, enter, timer, target in (
        ('WAIT_DELAY_1','turnOffReceiver()', 'endDelay_1','LISTENING_1'),
        ('LISTENING_1','turnOnReceiver()', 'endListening_1','WAIT_DELAY_2'),
        ('WAIT_DELAY_2','turnOffReceiver()', 'endDelay_2','LISTENING_2'),
        ('LISTENING_2','turnOnReceiver()', 'endListening_2','IDLE')):
        a = f'FSMA_State({state})\n        {{\n            FSMA_Enter({enter});'
        b = a + f'''\n            // Catch up after a receive/drop event consumed a window timeout.
            // No new event, packet or deadline is introduced.
            FSMA_No_Event_Transition({state}_Expired,
                    !{timer}->isScheduled() && {timer}->getArrivalTime() <= simTime(),
                    {target},
            );'''
        replacements.append((a,b))
    edit('src/LoRa/LoRaMac.cc', replacements)
    # Default calls are unchanged. Optional parameters permit isolated formula tests
    # for modes the archived transmitter did not expose (CRC/DE/preamble).
    edit('src/LoRaPhy/LoRaAirtimeCalculator.h', [
        ('int payloadBytes, int codeRedundance, bool useHeader)','int payloadBytes, int codeRedundance, bool useHeader,\n        bool useCrc = true, int forceDE = -1, int preambleSymbols = 8)'),
        ('const int lowDataRateOptimization = symbolDuration >= 0.016 ? 1 : 0;','const int lowDataRateOptimization = forceDE < 0 ? (symbolDuration >= 0.016 ? 1 : 0) : forceDE;'),
        ('+ 16.0 - 20.0 * implicitHeader;', '+ 16.0 * (useCrc ? 1 : 0) - 20.0 * implicitHeader;'),
        ('result.preamble = (8.0 + 4.25) * symbolDuration;\n    result.header = headerSymbols', 'result.preamble = (preambleSymbols + 4.25) * symbolDuration;\n    result.header = headerSymbols'),
    ])
    for f in ('ComponentProbe.cc','ComponentProbe.ned'):
        shutil.copy2(HERE/f, OUT/'src'/f)
    archived=(SOURCE/'src/LoRaPhy/LoRaAirtimeCalculator.h').read_text()
    archived=archived.replace('LORAPHY_LORAAIRTIMECALCULATOR_H_', 'AUDIT_ARCHIVED_AIRTIME_H_').replace('namespace flora {','namespace floraArchived {')
    (OUT/'src/ArchivedAirtimeCalculator.h').write_text(archived)
    (OUT/'component-changes.patch').write_text(''.join(patch))
    (OUT/'parent-source-hashes.json').write_text(json.dumps(parent_hashes,indent=2)+'\n')
    (OUT/'candidate-version.txt').write_text('enhanced-flora-review-component-candidate-20261029-v1\nParent: observation-3 factorial; not the historical 900-run binary.\n')
    ini = '''include fidelity-ablation.ini

[Config ComponentAudit]
extends = FidelityF5EnhancedStatic
network = flora.ComponentAuditNetwork
repeat = 1
**.numberOfNodes = 1
sim-time-limit = 30s
warmup-period = 2s
**.numberOfPacketsToSend = 0
**.audit.outputFile = "component-observed.csv"
**.schedulerProbe.outputFile = "scheduler-observed.csv"
**.schedulerProbe.attempts = "scheduler-input.csv"
'''
    (OUT/'simulations/examples/reviewer-components.ini').write_text(ini)
    print(OUT)

if __name__ == '__main__': main()
