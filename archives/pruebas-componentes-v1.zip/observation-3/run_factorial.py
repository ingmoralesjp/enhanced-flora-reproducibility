#!/usr/bin/env python3
"""Run item-3 pilot gates, then the 120 separately receipted factorial jobs."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timezone
import hashlib
import itertools
import json
import math
import os
from pathlib import Path
import shlex
import subprocess

COMBOS = list(itertools.product((0, 1), repeat=3))
POINTER_DIAGNOSTICS = {"rcvBelowSensitivity_NotCollided", "Total_rcvBelowSensitivity"}


def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()


def parse(path):
    values, attrs = {}, {}
    with path.open() as stream:
        for line in stream:
            if line.startswith("scalar "):
                row = shlex.split(line)
                values[(row[1], row[2])] = float(row[3])
            elif line.startswith("attr "):
                row = line.split(maxsplit=2)
                if len(row) == 3: attrs.setdefault(row[1], row[2].strip())
    return values, attrs


def same(x, y):
    return x == y or math.isnan(x) and math.isnan(y)


def atomic(path, value):
    temporary = path.with_suffix(".tmp")
    temporary.write_text(json.dumps(value, indent=2) + "\n")
    temporary.replace(path)


def fingerprint(values):
    names = {"initialPositionX", "initialPositionY", "initialLoRaSF", "initialLoRaTP",
             "trafficScheduleHashLow", "trafficScheduleHashHigh", "sentPackets"}
    return {f"{m}|{n}": v for (m, n), v in values.items() if ".loRaNodes[" in m and n in names}


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("mode", choices=("pilot", "campaign"))
    p.add_argument("--testbed", type=Path, required=True)
    p.add_argument("--baseline-lib", type=Path, required=True)
    p.add_argument("--inet-dir", type=Path, required=True)
    p.add_argument("--opp-run", type=Path, required=True)
    p.add_argument("--output", type=Path, required=True)
    p.add_argument("--gate", type=Path)
    p.add_argument("--jobs", type=int, default=8)
    p.add_argument("--resume", action="store_true")
    args = p.parse_args()
    root, baseline, inet, opp, out = (x.resolve() for x in
        (args.testbed, args.baseline_lib, args.inet_dir, args.opp_run, args.output))
    if not 1 <= args.jobs <= 10: p.error("Use 1--10 concurrent jobs")
    lib, inetlib = (root / "src/libflora.so").resolve(), (inet / "src/libINET.so").resolve()
    identity = {"factorial_manifest_sha256": sha(root / "factorial-manifest.json"),
        "library_sha256": sha(lib), "baseline_library_sha256": sha(baseline),
        "inet_library_sha256": sha(inetlib), "opp_run_sha256": sha(opp),
        "config_sha256": sha(root / "simulations/examples/reviewer-factorial.ini"),
        "runner_sha256": sha(Path(__file__)), "mode": args.mode}
    if args.mode == "campaign":
        if not args.gate: p.error("A successful pilot receipt is required")
        gate = json.loads(args.gate.read_text())
        if gate.get("status") != "PASS" or any(gate["identity"].get(k) != v for k, v in identity.items() if k != "mode"):
            p.error("Pilot failed or an input identity changed")
    if args.resume:
        if json.loads((out / "identity.json").read_text()) != identity: p.error("Resume identity mismatch")
    else:
        if out.exists(): p.error("Use a new output directory or --resume")
        out.mkdir(parents=True)
        atomic(out / "identity.json", identity)

    def run(combo, nodes, repetition, baseline_run=False):
        a, g, d = combo
        name = f"A{a}G{g}D{d}-n{nodes}-r{repetition}" + ("-baseline" if baseline_run else "")
        folder = out / name
        folder.mkdir(exist_ok=True)
        accepted = folder / "accepted.json"
        if accepted.exists():
            receipt = json.loads(accepted.read_text())
            if all(sha(folder / k) == v for k, v in receipt["files_sha256"].items()): return receipt
            raise RuntimeError(f"Accepted output changed: {name}")
        scalar, log = folder / "run.sca", folder / "run.log"
        if scalar.exists() or log.exists(): raise RuntimeError(f"Unaccepted attempt preserved: {name}")
        config = f"AuditA{a}G{g}D{d}"
        native_run = (nodes // 100 - 1) * 5 + repetition
        env = os.environ.copy()
        env.pop("FLORA_AUDIT_TRACE", None)
        env.pop("FLORA_AUDIT_RUN", None)
        env.pop("FLORA_AUDIT_PROFILE", None)
        if not baseline_run:
            env.update(FLORA_AUDIT_TRACE=str(folder / "adr-events.csv"), FLORA_AUDIT_RUN=name,
                       FLORA_AUDIT_PROFILE="adr")
        command = [str(opp), "-u", "Cmdenv", "-c", config, "-r", str(native_run),
            "-n", f"{root/'src'}:{root/'simulations'}:{inet/'src'}",
            "-l", str(baseline if baseline_run else lib), "-l", str(inetlib),
            f"--output-scalar-file={scalar}"]
        limit = 86400 if args.mode == "pilot" else 1036800
        if args.mode == "pilot": command += ["--sim-time-limit=86400s", "--warmup-period=0s"]
        command.append("reviewer-factorial.ini")
        with log.open("x") as stream:
            result = subprocess.run(command, cwd=root / "simulations/examples", env=env,
                                    stdout=stream, stderr=subprocess.STDOUT)
        text = log.read_text(errors="replace")
        checks = {"exit_zero": result.returncode == 0, "scalar_exists": scalar.is_file(),
                  "horizon": f"Simulation time limit reached -- at t={limit}s" in text,
                  "termination": "End." in text}
        if scalar.is_file():
            values, attrs = parse(scalar)
            checks.update(configuration=attrs.get("configname") == config,
                          repetition=attrs.get("repetition") == str(repetition),
                          seed=attrs.get("seedset") == str(repetition))
            if d == 0:
                checks["fixed_SF_TP"] = all(v == 0 for (m, n), v in values.items() if ".loRaNodes[" in m and n in ("SFChanges", "TPChanges", "ADRRecoverySteps", "receivedADRCommands"))
                checks["no_downlinks"] = values[("LoRaNetworkTest.loRaGW[0].LoRaGWNic.mac", "GW_forwardedDown")] == 0
        receipt = {"status": "PASS" if all(checks.values()) else "FAIL", "run_id": name,
            "factors": {"A": a, "G": g, "D": d}, "nodes": nodes, "repetition": repetition,
            "seed": repetition, "native_run": native_run, "baseline_run": baseline_run,
            "checks": checks, "command": command, "finished_at_utc": datetime.now(timezone.utc).isoformat(),
            "files_sha256": {x.name: sha(x) for x in folder.iterdir() if x.is_file()}}
        atomic(accepted if receipt["status"] == "PASS" else folder / "failed.json", receipt)
        return receipt

    jobs = [(combo, n, r, False) for combo in COMBOS
            for n in ((100,) if args.mode == "pilot" else (100, 500, 1000))
            for r in (range(1) if args.mode == "pilot" else range(5))]
    if args.mode == "pilot": jobs += [(combo, 100, 0, True) for combo in COMBOS]
    results = []
    atomic(out / "status.json", {"status": "RUNNING", "accepted": 0, "failed": 0,
        "total": len(jobs), "identity": identity, "concurrency_limit": args.jobs, "pid": os.getpid()})
    with ThreadPoolExecutor(max_workers=args.jobs) as pool:
        for future in as_completed([pool.submit(run, *job) for job in jobs]):
            receipt = future.result()
            results.append(receipt)
            counts = {state: sum(x["status"] == state for x in results) for state in ("PASS", "FAIL")}
            atomic(out / "status.json", {"status": "RUNNING", "accepted": counts["PASS"],
                "failed": counts["FAIL"], "total": len(jobs), "identity": identity,
                "concurrency_limit": args.jobs, "pid": os.getpid(), "results": results})
            print(json.dumps({"run_id": receipt["run_id"], "status": receipt["status"]}), flush=True)

    checks = {"all_runs_accepted": all(x["status"] == "PASS" for x in results)}
    details = {}
    for nodes in ((100,) if args.mode == "pilot" else (100, 500, 1000)):
        for rep in (range(1) if args.mode == "pilot" else range(5)):
            cells = {combo: parse(out / f"A{combo[0]}G{combo[1]}D{combo[2]}-n{nodes}-r{rep}/run.sca")[0] for combo in COMBOS}
            first = fingerprint(cells[(0, 0, 0)])
            key = f"n{nodes}-r{rep}"
            checks["offered_load_and_initial_identity_" + key] = all(fingerprint(v) == first for v in cells.values())
            for a in (0, 1):
                one, two = cells[(a, 0, 0)], cells[(a, 1, 0)]
                differences = [f"{m}|{n}" for (m, n), value in one.items()
                               if n != "GW_dutyCycleModelCode" and (m, n) in two and not same(value, two[(m, n)])]
                checks[f"negative_control_A{a}_" + key] = not differences
                if differences: details[f"negative_control_A{a}_" + key] = differences[:30]
            if args.mode == "pilot":
                for combo, values in cells.items():
                    a, g, d = combo
                    old = parse(out / f"A{a}G{g}D{d}-n100-r0-baseline/run.sca")[0]
                    diagnostic_differences = [f"{m}|{n}" for (m, n), value in old.items()
                                              if (m, n) in values and n in POINTER_DIAGNOSTICS and not same(value, values[(m, n)])]
                    differences = [f"{m}|{n}" for (m, n), value in old.items()
                                   if (m, n) in values and n not in POINTER_DIAGNOSTICS and not same(value, values[(m, n)])]
                    checks[f"passive_metrics_A{a}G{g}D{d}"] = not differences
                    if differences: details[f"passive_metrics_A{a}G{g}D{d}"] = differences[:30]
                    if diagnostic_differences:
                        details[f"pointer_sensitive_diagnostic_differences_A{a}G{g}D{d}"] = diagnostic_differences
    status = {"status": "PASS" if all(checks.values()) else "FAIL", "identity": identity,
              "accepted": sum(x["status"] == "PASS" for x in results), "total": len(jobs),
              "checks": checks, "details": details, "results": results,
              "equivalence_boundary": "All shared physical/primary scalars must match. Two pointer-deduplicated diagnostic loss counters are reported separately and are not treated as stable primary outcomes."}
    atomic(out / "status.json", status)
    print(json.dumps({"status": status["status"], "accepted": status["accepted"], "checks": checks}), flush=True)
    return 0 if status["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
