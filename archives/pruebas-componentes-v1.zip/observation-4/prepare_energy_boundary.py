#!/usr/bin/env python3
"""Additional isolated F5 test adapter; never rebuild the active MAC candidate."""
from pathlib import Path
import shutil

HERE=Path(__file__).resolve().parent
source=HERE/'testbed/flora';out=HERE/'testbed/energy-boundary'
out.mkdir(parents=True,exist_ok=False)
shutil.copy2(source/'Makefile',out/'Makefile')
shutil.copytree(source/'src',out/'src',ignore=shutil.ignore_patterns('Makefile','*.so','out','__pycache__'))
shutil.copytree(source/'simulations',out/'simulations')
f=out/'src/ComponentProbe.cc';s=f.read_text()
anchor='class GivenSnir : public ScalarSnir {'
fake='''// Controlled state input to the actual production energy consumer.
class CurrentTestRadio : public LoRaRadio {
public:
    RadioMode mode=RADIO_MODE_TRANSMITTER;
    ReceptionState rx=RECEPTION_STATE_RECEIVING;
    TransmissionState tx=TRANSMISSION_STATE_TRANSMITTING;
    RadioMode getRadioMode() const override { return mode; }
    ReceptionState getReceptionState() const override { return rx; }
    TransmissionState getTransmissionState() const override { return tx; }
};

'''
s=s.replace(anchor,fake+anchor)
anchor='        // Minimal native FSM reproductions, with every deadline already expired.'
extra='''        // Complete radiated-watts -> dBm -> table -> supply-power path.
        auto realRadio=ec->radio;
        auto testRadio=new CurrentTestRadio();
        ec->radio=testRadio;
        for(double db=-1.;db<=17.;db+=.25) {
            testRadio->setCurrentTxPower(std::pow(10.,(db-30.)/10.));
            row("F5_native_power",std::to_string(db),ec->computePowerBreakdown().total().get(),std::to_string(db));
        }
        // State integration over [0,12], clipped at the 2-second warm-up.
        ec->lastEnergyUpdate=0; ec->completeRunEnergy=LoRaEnergyConsumer::EnergyBreakdown();
        ec->measurementEnergy=LoRaEnergyConsumer::EnergyBreakdown();
        testRadio->setCurrentTxPower(.01); // +10 dBm -> 31 mA
        testRadio->mode=IRadio::RADIO_MODE_TRANSMITTER;
        ec->previousPower=ec->computePowerBreakdown();ec->integrateEnergyUntil(1);
        testRadio->mode=IRadio::RADIO_MODE_RECEIVER;
        ec->previousPower=ec->computePowerBreakdown();ec->integrateEnergyUntil(4);
        testRadio->rx=IRadio::RECEPTION_STATE_IDLE;
        ec->previousPower=ec->computePowerBreakdown();ec->integrateEnergyUntil(7);
        testRadio->mode=IRadio::RADIO_MODE_SLEEP;
        ec->previousPower=ec->computePowerBreakdown();ec->integrateEnergyUntil(12);
        row("F5_native_state_energy","TX",ec->measurementEnergy.tx.get(),"0;1;2");
        row("F5_native_state_energy","RX",ec->measurementEnergy.rx.get(),"1;4;2");
        row("F5_native_state_energy","idle",ec->measurementEnergy.idle.get(),"4;7;2");
        row("F5_native_state_energy","sleep",ec->measurementEnergy.sleep.get(),"7;12;2");
        ec->radio=realRadio;delete testRadio;
'''
if s.count(anchor)!=1:raise ValueError('Non-unique insertion')
f.write_text(s.replace(anchor,extra+anchor))
print(out)
