// SPDX-License-Identifier: LGPL-3.0-or-later
#include "AuditTrace.h"
#include <algorithm>
#include <cmath>
#include <cstdlib>
#include <fstream>
#include <iomanip>
#include <map>
#include <string>
#include "LoRa/LoRaMacFrame_m.h"
#include "LoRaPhy/LoRaPhyPreamble_m.h"
#include "LoRaPhy/LoRaTransmission.h"

namespace flora { namespace audit {
namespace {
struct Writer {
    std::ofstream events, intervals;
    std::string run;
    bool adrOnly = false;
    std::map<long, long> attempts;
    std::map<long, long> addresses;
    Writer() {
        const char *path = std::getenv("FLORA_AUDIT_TRACE");
        const char *id = std::getenv("FLORA_AUDIT_RUN");
        run = id ? id : "unspecified";
        const char *profile = std::getenv("FLORA_AUDIT_PROFILE");
        adrOnly = profile && std::string(profile) == "adr";
        if (path && *path) {
            events.open(path);
            intervals.open(std::string(path) + ".energy.csv");
            if (!events || !intervals)
                throw omnetpp::cRuntimeError("Cannot open audit output");
            events << "run_id,time_s,in_measurement_window,component,event,packet_tree,device_id,sequence,attempt,SF,tx_power_dBm,frequency_Hz,packet_bytes,start_s,end_s,reason,value1,value2,value3,value4\n";
            intervals << "run_id,device_id,start_s,end_s,measurement_start_s,measurement_seconds,tx_W,rx_W,idle_W,sleep_W,other_W\n";
            events << std::setprecision(17);
            intervals << std::setprecision(17);
        }
    }
};
Writer& writer() { static Writer instance; return instance; }
std::string quote(const std::string& value) {
    std::string result = "\"";
    for (char c : value) { if (c == '"') result += '"'; result += c; }
    return result + "\"";
}
long device(const omnetpp::cComponent *component) {
    const std::string path = component->getFullPath();
    const std::string marker = ".loRaNodes[";
    const auto pos = path.find(marker);
    return pos == std::string::npos ? -1 : std::stol(path.substr(pos + marker.size()));
}
struct Identity {
    long dev = -1, seq = -1;
    int sf = -1;
    double power = NAN, frequency = NAN;
    long bytes = -1;
    bool downlink = false;
};
Identity identity(const omnetpp::cComponent *component, const inet::Packet *pkt) {
    Identity out;
    out.dev = device(component);
    if (!pkt) return out;
    out.bytes = (pkt->getDataLength().get() + 7) / 8;
    const auto chunk = pkt->peekAtFront<inet::FieldsChunk>();
    auto frame = inet::dynamicPtrCast<const LoRaMacFrame>(chunk);
    const auto preamble = inet::dynamicPtrCast<const LoRaPhyPreamble>(chunk);
    if (preamble) {
        frame = pkt->peekDataAt<LoRaMacFrame>(preamble->getChunkLength());
        out.bytes -= (preamble->getChunkLength().get() + 7) / 8;
        out.power = 10 * std::log10(preamble->getPower().get() * 1000);
    }
    if (frame) {
        const bool up = frame->getReceiverAddress().isBroadcast();
        out.downlink = !up;
        const long address = (up ? frame->getTransmitterAddress() : frame->getReceiverAddress()).getInt();
        if (up && out.dev >= 0 && std::string(component->getFullName()) == "mac")
            writer().addresses[address] = out.dev;
        const auto found = writer().addresses.find(address);
        out.dev = found == writer().addresses.end() ? -1 : found->second;
        out.seq = frame->getSequenceNumber();
        out.sf = frame->getLoRaSF();
        out.frequency = frame->getLoRaCF().get();
        if (!preamble)
            out.power = 10 * std::log10(frame->getLoRaTP() * (up ? 1000.0 : 1.0));
    }
    return out;
}
void row(const omnetpp::cComponent *component, const char *event,
         const inet::Packet *pkt, Identity id, const char *reason,
         double a, double b, double c, double d,
         omnetpp::simtime_t start, omnetpp::simtime_t end) {
    auto& w = writer();
    if (!w.events.is_open()) return;
    if (w.adrOnly) {
        const std::string name = event;
        const bool keep = name.find("ADR_") == 0 || name.find("GW_DOWNLINK_") == 0 ||
            ((name == "PHY_TX_START" || name == "PHY_TX_END") && std::string(component->getFullPath()).find(".loRaGW[") != std::string::npos) ||
            ((name == "ED_RX_SUCCESS" || name == "ED_RX_FAILED") && id.downlink);
        if (!keep) return;
    }
    const auto time = omnetpp::simTime();
    const bool window = time >= omnetpp::cSimulation::getActiveSimulation()->getWarmupPeriod();
    const long tree = pkt ? pkt->getTreeId() : -1;
    const auto count = w.attempts.find(tree);
    w.events << quote(w.run) << ',' << time.dbl() << ',' << window << ','
             << quote(component->getFullPath()) << ',' << event << ',' << tree << ','
             << id.dev << ',' << id.seq << ',' << (count == w.attempts.end() ? 0 : count->second)
             << ',' << id.sf << ',' << id.power << ',' << id.frequency << ',' << id.bytes
             << ',' << start.dbl() << ',' << end.dbl() << ',' << quote(reason)
             << ',' << a << ',' << b << ',' << c << ',' << d << '\n';
    if (!w.events) throw omnetpp::cRuntimeError("Audit trace write failed");
}
}
bool enabled() { return writer().events.is_open(); }
void packet(const omnetpp::cComponent *component, const char *event,
            const inet::Packet *pkt, const char *reason,
            double a, double b, double c, double d, long sequence,
            omnetpp::simtime_t start, omnetpp::simtime_t end) {
    if (!enabled()) return;
    auto id = identity(component, pkt);
    if (sequence >= 0) id.seq = sequence;
    row(component, event, pkt, id, reason, a, b, c, d, start, end);
}
void generated(const omnetpp::cComponent *component, const inet::Packet *pkt,
               long sequence, int sf, double powerDbm, double frequencyHz) {
    if (!enabled()) return;
    auto id = identity(component, pkt);
    id.seq = sequence; id.sf = sf; id.power = powerDbm; id.frequency = frequencyHz;
    row(component, "APP_GENERATED", pkt, id, "data", NAN, NAN, NAN, NAN, -1, -1);
}
void phy(const omnetpp::cComponent *component, const char *event,
         const inet::physicallayer::ITransmission *transmission, const char *reason) {
    if (!enabled()) return;
    const auto pkt = transmission->getPacket();
    auto id = identity(component, pkt);
    const auto lora = dynamic_cast<const LoRaTransmission *>(transmission);
    if (lora) {
        id.sf = lora->getLoRaSF(); id.power = 10 * std::log10(lora->getLoRaTP().get() * 1000);
        id.frequency = lora->getLoRaCF().get();
    }
    if (std::string(event) == "PHY_TX_START") writer().attempts[pkt->getTreeId()]++;
    row(component, event, pkt, id, reason, NAN, NAN, NAN, NAN,
        transmission->getStartTime(), transmission->getEndTime());
}
void state(const omnetpp::cComponent *component, const char *event,
           const inet::Packet *pkt, int beforeSf, int afterSf,
           double beforePower, double afterPower) {
    packet(component, event, pkt, "SF_before,SF_after,TP_before,TP_after",
           beforeSf, afterSf, beforePower, afterPower);
}
void energy(const omnetpp::cComponent *component, omnetpp::simtime_t start,
            omnetpp::simtime_t end, double tx, double rx, double idle,
            double sleep, double other) {
    if (!enabled() || writer().adrOnly) return;
    auto& w = writer();
    const auto warmup = omnetpp::cSimulation::getActiveSimulation()->getWarmupPeriod();
    const auto measured = std::max(start, warmup);
    const double seconds = end > measured ? (end - measured).dbl() : 0;
    w.intervals << quote(w.run) << ',' << device(component) << ',' << start.dbl() << ','
                << end.dbl() << ',' << measured.dbl() << ',' << seconds << ','
                << tx << ',' << rx << ',' << idle << ',' << sleep << ',' << other << '\n';
    if (!w.intervals) throw omnetpp::cRuntimeError("Audit energy write failed");
}
} }
