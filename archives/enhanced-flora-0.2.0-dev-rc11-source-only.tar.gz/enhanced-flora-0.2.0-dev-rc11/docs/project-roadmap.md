# Enhanced FLoRa: closure and repository roadmap

Decision recorded: 2026-10-11. This is **one platform paper and one
repository-ready research compendium**. The separate ADR-algorithm papers are
not merged into it. No accepted result is stopped, deleted, overwritten, or
silently replaced by this plan.

## Keep the evidence identities separate

| Identity | Source and results | Interpretation |
|---|---|---|
| Historical Enhanced `0.1.0-dev` | F0--F5, 900/900 accepted, `samples/flora/simulations/results/fidelity-ablation-20260909/` | Audited within-version ablation; predates the MAC reentry correction. Never relabel as `0.2.0-dev`. |
| Corrected Enhanced `0.2.0-dev` | Frozen source and inputs under `results/fidelity-ablation-corrected-v0.2.0-dev/state/`; corrected summaries under `analysis/` | Completed F0--F5 matrix: 6 stages x 3 populations x 10 node counts x 5 repetitions = 900 accepted runs, independently reaudited. Keep its source, library, INI, and results immutable. |
| Pristine official FLoRa 1.1.0 | Separate testbed `../../adr-m1-m2-replication/testbeds/flora-1.1-official-legacy/` | External stack-level reference, static only; not F0 and not a seed-paired causal contrast. Complete 100-seed survey: 92 accepted, eight failed; no failed-run PDR. These failures do not prove a density ceiling. |

The official compatibility fork is a separately modified identity. Its MAC
guard is not behaviorally equivalent to pristine FLoRa and must not fill
missing pristine results. Preserve the historical failure report as evidence
of the interrupted first attempt; subsequent runs need separate receipts.

## Work packages and acceptance gates

Current execution order: close the corrected analysis (1); finish and audit
pristine FLoRa 1.1 (3); analyze, conclude, compile, and email the standalone
platform paper (4); freeze its reproducible compendium (5); only then screen
end-device duty cycle in a separately versioned Enhanced testbed (2). The
numbers below identify work packages, not chronological execution.

1. **Close the corrected Enhanced matrix and paper analysis.** The 900/900
   runs finished with zero recorded failures; an independent read-only pass
   rechecked receipts, frozen source identity, configuration, and horizon.
   The 900 run rows, 180 complete cells, 300 paired contrasts, and corrected
   figures/tables are now generated separately from historical data. Review
   mechanisms and manuscript claims before freezing the release.
2. **Post-paper end-device duty screen in an isolated version.** Keep the corrected
   matrix immutable. Add a separately versioned, switchable ED-duty mechanism
   and first prove that switching it *off* reproduces the frozen F5 control.
   Then run one paired repetition with ED duty off/on at every density from
   100 to 1000 devices, for static, mobile, and mixed populations: 60 full-
   horizon runs. Keep seed, offered traffic, ADR, gateway duty, 20-byte payload,
   and three uplink channels matched within each pair. Use actual uplink
   airtime and the configured shared-sub-band 1% budget. Record generated,
   transmitted, deferred, queued, dropped, and delivered packets; duty
   violations, delay/occupancy, per-SF airtime, both delivery denominators,
   throughput, and energy per delivered packet. Set practical PDR/energy
   screening criteria from pre-pilot evidence before reading pilot outcomes.
   A one-repetition change is a diagnostic signal, not statistical proof.
   **Only if PDR or energy changes enough to matter** extend to ten total
   paired repetitions per density/population (600 total off/on runs, counting
   the pilot seed if valid). If effects are minor, defer the full ED-duty
   campaign. The platform paper already states that ED duty is absent from its
   evaluated version; a post-paper result belongs in a separately versioned
   follow-up, not a retroactive claim. Do not describe a PDR rise caused solely
   by fewer transmissions as reliability improvement.
3. **Pristine official exploration through 1000 nodes: completed.** All 100
   seeds were attempted under the sealed manifest: 92 passed the full-horizon
   receipt/scalar audit and eight failed. Never replace a failed seed, shorten
   the horizon, silently patch the binary, or report failed cells as measured
   PDR. Report coverage and failure rate by density. The official and
   Enhanced stacks remain unpaired, and the completed-run official means are
   conditional on acceptance.
4. **Analyze and write the single platform paper.** Show provenance and the
   source-difference matrix, validation hierarchy, corrected F0--F5 effects,
   and the official comparison with its completion map. Compile and email the
   final PDF to moralesalvarez@gmail.com; email substantive paper/PDF updates and any
   verified simulation stop. Use run-level paired contrasts and uncertainty
   only where replications support them. Explain alternative causes and
   limitations rather than attributing a whole-stack PDR difference to ADR.
5. **Freeze a downloadable release candidate.** Package clean Enhanced source,
   configurations, tests, runners, analysis, compact run-level data, paper
   sources, license/attribution, pinned dependencies, and a SHA-256 manifest.
   Include official testbed recipes and provenance without mixing its source,
   binary, or output into Enhanced results. Publish large raw scalars as a
   separately hashed dataset, not as Git history. Perform a fresh build,
   verification, paper regeneration, and archive hash check before calling
   the artifact release-ready.

## Result-to-claim trace

Every final table and figure needs a reproducible path: versioned source +
INI + seed + toolchain -> run log/scalar -> acceptance receipt -> run-level
CSV -> analysis script -> table/figure -> manuscript claim. Source changes
are indexed in `change-inventory.md` and claim boundaries in
`reviewer-claim-matrix.md`. The current `scripts/assemble_release.py` output
is a **development snapshot**, not the final corrected-data compendium.

## Current paper boundary

The manuscript in `samples/flora/docs/enhanced-flora-platform-paper/` is a
working draft of a new, self-contained platform paper. The corrected 900-run
analysis is its primary Enhanced evidence; the historical matrix is provenance,
not pooled data. The complete official static survey has 92 accepted runs
and eight failures among 100 attempts. The ED-duty screen is a conditional
post-paper extension: a small diagnostic effect does not require a ten-rep
campaign, but the absence of ED duty must remain explicit. Do not label the
paper or download package final before the open
gates are passed or their failures are reported transparently.
