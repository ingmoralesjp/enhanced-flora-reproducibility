#!/usr/bin/env python3
"""Native paired regression runs; preserve each attempt, never reuse a failed output."""
import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess

HERE=Path(__file__).resolve().parent
ROOT=next(p for p in HERE.parents if (p/'bin/opp_run').exists())
INET=ROOT/'samples/inet'
spec=importlib.util.spec_from_file_location('factorial',HERE.parent/'observation-3/run_factorial.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)

def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
def atomic(f,d):
    t=f.with_suffix('.tmp');t.write_text(json.dumps(d,indent=2)+'\n');t.replace(f)

def main():
    p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);p.add_argument('--jobs',type=int,default=8);a=p.parse_args()
    out=a.output.resolve();out.mkdir(parents=True,exist_ok=False)
    libs={'parent':HERE.parent/'observation-3/testbed/flora/src/libflora.so','identity':HERE/'testbed/identity-only/src/libflora.so','corrected':HERE/'testbed/flora/src/libflora.so'}
    configs=('FidelityValidateF0','FidelityValidateF1','FidelityValidateF2','FidelityValidateF3','FidelityValidateF4','FidelityValidateF5','FidelityValidateLegacyDuty','FidelityValidateToaDuty','FidelityValidateF5Mobile','FidelityValidateF5Mixed')
    jobs=[(mode,c,0,None) for mode in libs for c in configs]
    jobs += [('corrected','FidelityF2SnrReceptionStatic',0,3000),('corrected','FidelityF2SnrReceptionStatic',0,1036800),('corrected','FidelityF5EnhancedStatic',45,1036800)]
    atomic(out/'status.json',{'status':'RUNNING','total':len(jobs),'accepted':0,'pid':os.getpid()})
    def run(mode,c,r,limit):
        name=f'{mode}-{c}-r{r}'+(f'-{limit}s' if limit else '')
        d=out/name;d.mkdir();root=HERE/'testbed/flora'
        overlay=d/'run.ini';overlay.write_text('include '+str(root/'simulations/examples/fidelity-ablation.ini')+'\n\n[General]\n**.cmdenv-log-level=off\n')
        cmd=[str(ROOT/'bin/opp_run'),'-u','Cmdenv','-c',c,'-r',str(r),'-n',f'{root/"src"}:{root/"simulations"}:{INET/"src"}','-l',str(libs[mode]),'-l',str(INET/'src/libINET.so'),f'--output-scalar-file={d/"run.sca"}']
        if limit:cmd += [f'--sim-time-limit={limit}s']
        if limit==3000:cmd += ['--cmdenv-express-mode=false','--cmdenv-event-banners=false','--cmdenv-log-prefix=%t|%l|%J|','--LoRaNetworkTest.loRaNodes[1].LoRaNic.mac.cmdenv-log-level=detail']
        cmd.append(str(overlay));env=os.environ.copy()
        for k in ('FLORA_AUDIT_TRACE','FLORA_AUDIT_RUN','FLORA_AUDIT_PROFILE'):env.pop(k,None)
        with (d/'run.log').open('x') as f:proc=subprocess.run(cmd,cwd=root/'simulations/examples',env=env,stdout=f,stderr=subprocess.STDOUT)
        text=(d/'run.log').read_text(errors='replace')
        ok=proc.returncode==0 and 'Simulation time limit reached' in text and 'End.' in text and (d/'run.sca').exists()
        receipt={'status':'PASS' if ok else 'FAIL','mode':mode,'config':c,'run':r,'limit':limit,'command':cmd,'library_sha256':sha(libs[mode]),'returncode':proc.returncode,'files_sha256':{f.name:sha(f) for f in d.iterdir() if f.is_file()}}
        atomic(d/'receipt.json',receipt)
        return name,receipt
    done={}
    with ThreadPoolExecutor(max_workers=a.jobs) as pool:
        for future in as_completed([pool.submit(run,*job) for job in jobs]):
            name,receipt=future.result();done[name]=receipt
            atomic(out/'status.json',{'status':'RUNNING','total':len(jobs),'accepted':sum(r['status']=='PASS' for r in done.values()),'done':done,'pid':os.getpid()});print(name,receipt['status'],flush=True)
    checks={'all_native_runs':all(r['status']=='PASS' for r in done.values())};details={}
    for c in configs:
        one,_=mod.parse(out/f'parent-{c}-r0/run.sca');two,_=mod.parse(out/f'identity-{c}-r0/run.sca')
        diffs=[f'{m}|{n}' for (m,n),v in one.items() if (m,n) in two and n not in mod.POINTER_DIAGNOSTICS and not mod.same(v,two[m,n])]
        checks['identity_preserves_primary_'+c]=not diffs
        details[c]={'primary_differences':diffs,'diagnostic_differences':[f'{m}|{n}' for (m,n),v in one.items() if (m,n) in two and n in mod.POINTER_DIAGNOSTICS and not mod.same(v,two[m,n])]}
    short=out/'corrected-FidelityF2SnrReceptionStatic-r0-3000s/run.log'
    lines=[]
    for line in short.read_text().splitlines():
        try:t=float(line.split('|')[0])
        except ValueError:continue
        if 2902<=t<=2970:lines.append(line)
    (out/'corrected-selected-timer-events.log').write_text('\n'.join(lines)+'\n')
    checks['native_reproducer_subsequent_tx']=any('2967.48924943833' in l and 'sending Data frame' in l for l in lines)
    # A full-horizon check reports final state/queue for the formerly blocked device.
    values,_=mod.parse(out/'corrected-FidelityF2SnrReceptionStatic-r0-1036800s/run.sca')
    device='LoRaNetworkTest.loRaNodes[1].LoRaNic.mac'
    former={n:v for (m,n),v in values.items() if m==device}
    checks['formerly_blocked_device_not_persistently_queued']=former.get('auditPendingMeasurementPackets',float('inf'))<=1
    status={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'details':details,'formerly_blocked_device':former,'done':done}
    atomic(out/'status.json',status);print(json.dumps({'status':status['status'],'checks':checks},indent=2),flush=True)
    return 0 if status['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
