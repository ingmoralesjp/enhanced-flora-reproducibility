// Native adapter: production LoRaLogNormalShadowing is compiled unchanged.
// SPDX-License-Identifier: LGPL-3.0-or-later
#include <omnetpp.h>
#include <cmath>
#include <fstream>
#include <iomanip>
#include <sstream>
#include "LoRaPhy/LoRaLogNormalShadowing.h"

namespace flora {
using namespace omnetpp;
struct Inputs {
    std::string id, group;
    double d0, gamma, sigma; int friis;
    double referenceDb, referenceHz, referenceSpeed, gt, gr, systemDb;
    double distance, argumentHz, argumentSpeed, txDbm;
};

class PropagationProbe : public cSimpleModule {
    int serial = 0;
    LoRaLogNormalShadowing *createLoss(const Inputs& p, cModule *&owned) {
        const std::string name = "loss_case_" + std::to_string(serial++);
        owned = cModuleType::get("flora.LoRaPhy.LoRaLogNormalShadowing")->create(name.c_str(), getParentModule());
        owned->par("d0").setDoubleValue(p.d0);
        owned->par("gamma").setDoubleValue(p.gamma);
        owned->par("sigma").setDoubleValue(p.sigma);
        owned->par("useFriisReference").setBoolValue(p.friis != 0);
        owned->par("referencePathLoss").setDoubleValue(p.referenceDb);
        owned->par("referenceFrequency").setDoubleValue(p.referenceHz);
        owned->par("propagationSpeed").setDoubleValue(p.referenceSpeed);
        owned->par("transmitterGain").setDoubleValue(p.gt);
        owned->par("receiverGain").setDoubleValue(p.gr);
        owned->par("systemLoss").setDoubleValue(p.systemDb);
        owned->finalizeParameters();
        owned->buildInside();
        owned->callInitialize();
        return check_and_cast<LoRaLogNormalShadowing *>(owned);
    }
    static std::string quoted(std::string s) {
        std::string r = "\"";
        for (char c : s) { if (c == '"') r += '"'; r += (c == '\n' || c == '\r') ? ' ' : c; }
        return r + "\"";
    }
    void initialize() override { scheduleAt(0, new cMessage("propagation-verification")); }
    void handleMessage(cMessage *event) override {
        delete event;
        if (par("runDeterministic").boolValue()) {
            std::ifstream in(par("inputFile").stringValue());
            std::ofstream out(par("outputFile").stringValue());
            if (!in || !out) throw cRuntimeError("Cannot open isolated propagation input/output");
            out << "case_id,group,attenuation_ratio,range_m,rejected,error_phase,error\n" << std::setprecision(17);
            Inputs p;
            while (in >> p.id >> p.group >> p.d0 >> p.gamma >> p.sigma >> p.friis
                    >> p.referenceDb >> p.referenceHz >> p.referenceSpeed >> p.gt >> p.gr
                    >> p.systemDb >> p.distance >> p.argumentHz >> p.argumentSpeed >> p.txDbm) {
                cModule *owned = nullptr;
                const char *phase = "initialize";
                try {
                    auto model = createLoss(p, owned);
                    phase = "computePathLoss";
                    double attenuation = model->computePathLoss(mps(p.argumentSpeed), Hz(p.argumentHz), m(p.distance));
                    phase = "computeLoRaRange";
                    double range = model->computeLoRaRange(W(std::pow(10., (p.txDbm - 30.) / 10.))).get();
                    out << p.id << ',' << p.group << ',' << attenuation << ',' << range << ",0,,\n";
                }
                catch (const cRuntimeError& error) {
                    out << p.id << ',' << p.group << ",,,1," << phase << ',' << quoted(error.what()) << '\n';
                }
                if (owned) owned->deleteModule();
            }
        }
        std::ofstream samples(par("samplesFile").stringValue());
        if (!samples) throw cRuntimeError("Cannot open isolated shadowing output");
        samples << "block,sample,attenuation_ratio\n" << std::setprecision(17);
        for (double sigma : {3.57, 7.08}) {
            Inputs p = {"", "", 1000., 2.32, sigma, 1, 127.41, 868e6, 299792458., 1., 1., 0., 15000., 868e6, 299792458., 14.};
            cModule *owned = nullptr;
            auto model = createLoss(p, owned);
            const char *block = sigma == 3.57 ? "sigma_3_57" : "sigma_7_08";
            for (int i = 0; i < par("samplesPerBlock").intValue(); ++i)
                samples << block << ',' << i << ',' << model->computePathLoss(mps(p.argumentSpeed), Hz(p.argumentHz), m(p.distance)) << '\n';
            owned->deleteModule();
        }
        samples.close();
    }
};
Define_Module(PropagationProbe);
} // namespace flora
