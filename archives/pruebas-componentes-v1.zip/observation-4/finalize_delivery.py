#!/usr/bin/env python3
"""Independent final gate and portable, checksummed item-4 evidence archive."""
import csv
import hashlib
import importlib.util
import json
from pathlib import Path
import zipfile

HERE=Path(__file__).resolve().parent
PROJECT=HERE.parent.parent

def sha(f):
    h=hashlib.sha256()
    with f.open('rb') as s:
        for b in iter(lambda:s.read(1024*1024),b''):h.update(b)
    return h.hexdigest()

def main():
    result=HERE/'results';reg=result/'regressions-v1'
    state=json.loads((reg/'status.json').read_text())
    if state['status']=='RUNNING':raise SystemExit('WAITING: native extended regression still running')
    spec=importlib.util.spec_from_file_location('factorial',HERE.parent/'observation-3/run_factorial.py')
    mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
    checks={}
    receipts=list(reg.glob('*/receipt.json'))
    checks['33_native_executions_complete']=len(receipts)==33 and all(json.loads(f.read_text())['status']=='PASS' for f in receipts)
    checks['native_receipt_outputs_match_hashes']=all(sha(f.parent/n)==v for f in receipts for n,v in json.loads(f.read_text())['files_sha256'].items())
    checks['ten_identity_only_primary_controls']=all(v for k,v in state.get('checks',{}).items() if k.startswith('identity_preserves_primary_')) and sum(k.startswith('identity_preserves_primary_') for k in state.get('checks',{}))==10
    component=json.loads((result/'portable-components-v1/status.json').read_text())
    checks['native_components_and_independent_oracles']=component['status']=='PASS'
    checks['native_watts_current_and_state_integration']=json.loads((result/'native-energy-v1/native-energy-status.json').read_text())['status']=='PASS'
    failed=json.loads((result/'original-component-repro-v1/status.json').read_text())
    checks['original_bug_reproduced_only_in_identity_and_progress']=failed['status']=='FAIL' and len(failed['failures'])==4 and {r['group'] for r in failed['failures']}=={'identity','MAC_progress'}
    text=(reg/'corrected-FidelityF2SnrReceptionStatic-r0-3000s/run.log').read_text()
    # Match the observed timeout/drop episode, rather than requiring later
    # traffic timestamps to stay identical after changing a stochastic model.
    checks['native_observed_drop_episode_reaches_RX2']=any('2906.80938567681' in l and 'Listening_2 in state: LISTENING_2' in l for l in text.splitlines())
    full,_=mod.parse(reg/'corrected-FidelityF2SnrReceptionStatic-r0-1036800s/run.sca')
    device='LoRaNetworkTest.loRaNodes[1].LoRaNic.mac'
    checks['formerly_blocked_device_full_horizon_no_pending']=full[device,'auditPendingMeasurementPackets']==0 and full[device,'numSent']>100
    checks['F5_all_150_historical_pairs_equal']=json.loads((result/'F5-campaign-audit.json').read_text())['status']=='PASS'
    findings={
        'independent_component_cases':sum(x['cases'] for x in component['groups'].values()),
        'scheduler_attempts':component['scheduler_attempts'],
        'formerly_blocked_device':{n:v for (m,n),v in full.items() if m==device},
        'native_oracle_correction':'The initial runner expected a later application timestamp to remain unchanged after MAC correction. That is not an input invariant in this inherited shared-RNG run. The preserved native episode instead verifies that the same RX2-close event arrives in LISTENING_2, not LISTENING_1. Direct fixed-input FSM regressions separately reproduce all three expired-deadline paths. The original runner result remains archived.',
        'boundaries':'No original campaign results were replaced. Exact dB equality is recorded but is not a calibrated-boundary assertion; no hardware validation is claimed.'}
    # Compare full native candidate outcomes descriptively; never pool campaigns.
    descriptions=[]
    for config,n,r in [('FidelityF2SnrReceptionStatic',100,0),('FidelityF5EnhancedStatic',1000,45)]:
        values,_=mod.parse(reg/f'corrected-{config}-r{r}-1036800s/run.sca')
        apps=[(m,v) for (m,k),v in values.items() if k=='sentPackets' and '.SimpleLoRaApp' in m]
        descriptions.append({'config':config,'nodes':n,'full_horizon_completed':True,'application_sent_scalar_modules':len(apps),'note':'Diagnostic candidate, one repetition, not a replacement for five-repetition campaign results.'})
    findings['extended_native_controls']=descriptions
    gate={'status':'PASS' if all(checks.values()) else 'FAIL','checks':checks,'findings':findings}
    (result/'final-verification.json').write_text(json.dumps(gate,indent=2)+'\n')
    if gate['status']!='PASS':print(json.dumps(gate,indent=2));raise SystemExit(1)
    delivery=PROJECT/'deliverables/observation-4';delivery.mkdir(parents=True,exist_ok=True)
    archive=delivery/'enhanced-flora-observation-4-components-v1.zip'
    if archive.exists():raise SystemExit('Refusing to overwrite issued archive')
    entries={}
    def collect(root,prefix):
        for f in sorted(root.rglob('*')):
            if not f.is_file() or f.is_symlink():continue
            if f.name in ('supervisor-status.json','supervisor.lock','continuation-queued.json','finalize.log','delivery-status.json'):continue
            if f.suffix in ('.so','.o','.d','.pyc') or '__pycache__' in f.parts:continue
            # Generated build products are independently identified by hashes;
            # dependencies are supplied by the explicit portable build.
            entries[str(Path(prefix)/f.relative_to(root))]=f
    for f in HERE.glob('*.py'):entries['observation-4/'+f.name]=f
    entries['observation-4/README.md']=HERE/'README.md'
    collect(result,'observation-4/results')
    for root in (HERE/'testbed/flora',HERE/'testbed/identity-only',HERE/'testbed/original-components',HERE/'testbed/energy-boundary'):
        collect(root,'observation-4/testbed/'+root.name)
    for f in HERE.glob('build-*.log'):entries['observation-4/build-logs/'+f.name]=f
    # Include parent source to make the preparation step independent of a personal checkout.
    parent=HERE.parent/'observation-3/testbed/flora'
    collect(parent/'src','observation-3/testbed/flora/src')
    collect(parent/'simulations','observation-3/testbed/flora/simulations')
    entries['observation-3/testbed/flora/Makefile']=parent/'Makefile'
    entries['observation-3/run_factorial.py']=HERE.parent/'observation-3/run_factorial.py'
    manifest={k:sha(f) for k,f in entries.items()}
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for name,f in entries.items():z.write(f,name)
        z.writestr('SHA256SUMS.json',json.dumps(manifest,indent=2)+'\n')
    with zipfile.ZipFile(archive) as z:
        if z.testzip():raise RuntimeError('CRC verification failed')
        for name,h in manifest.items():
            if hashlib.sha256(z.read(name)).hexdigest()!=h:raise RuntimeError(name)
    receipt={'status':'DELIVERY_READY','archive':str(archive),'sha256':sha(archive),'bytes':archive.stat().st_size,'files':len(manifest)+1,'verification':gate}
    (delivery/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
    (result/'delivery-status.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))

if __name__=='__main__':main()
