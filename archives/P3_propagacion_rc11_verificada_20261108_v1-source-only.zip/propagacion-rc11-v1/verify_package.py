#!/usr/bin/env python3
"""Check bytes and independently reanalyze the distributed native outputs."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import tempfile


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    root = args.root.resolve()
    manifest = json.loads((root/"MANIFEST.json").read_text())
    checks = {}
    for name, record in manifest["files"].items():
        path = (root/name).resolve()
        assert path.is_relative_to(root)
        checks["file:"+name] = path.is_file() and path.stat().st_size == record["bytes"] and sha(path) == record["sha256"]
    assert all(checks.values()), [key for key, ok in checks.items() if not ok]
    native = root/"results/native-v2"
    receipt = json.loads((native/"receipt.json").read_text())
    checks["native_receipt"] = receipt["status"] == "PASS" and receipt["protected_unchanged"] and receipt["protected_files"] == 393
    checks["protected_snapshots"] = (native/"protected-inputs-before.json").read_bytes() == (native/"protected-inputs-after.json").read_bytes()
    archive = root/"source/enhanced-flora-0.2.0-dev-rc11.tar.gz"
    with tarfile.open(archive) as tar:
        for name, digest in receipt["source_hashes"].items():
            data = tar.extractfile("enhanced-flora-0.2.0-dev-rc11/"+name).read()
            checks["frozen_source:"+name] = hashlib.sha256(data).hexdigest() == digest.removeprefix("sha256:") == sha(native/"work"/name)
    checks["analyzer_controls"] = json.loads((root/"results/oracle-controls-v1.json").read_text())["status"] == "PASS"
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1")
    with tempfile.TemporaryDirectory(prefix="p3-reanalysis-") as directory:
        scratch = Path(directory)/"outputs"
        shutil.copytree(native, scratch, ignore=shutil.ignore_patterns("analysis", "work"))
        process = subprocess.run([sys.executable, str(root/"oracle.py"), str(scratch)], capture_output=True, text=True, env=env)
        regenerated = json.loads((scratch/"analysis/status.json").read_text())
        original = json.loads((native/"analysis/status.json").read_text())
        checks["fresh_reanalysis"] = process.returncode == 0 and regenerated["status"] == "PASS"
        for key in ("numeric_comparisons", "input_rejection_cases", "shadowing_blocks", "shadowing_samples", "seeds"):
            checks["reanalysis:"+key] = regenerated[key] == original[key]
        checks["design_predeclared"] = json.loads((native/"DESIGN.json").read_text())["declared_before_native_execution_utc"] != ""
    status = dict(status="PASS" if all(checks.values()) else "FAIL", files_checked=len(manifest["files"]),
                  fresh_native_execution=False, fresh_analysis=True, checks=checks)
    (root/"PACKAGE_VERIFICATION.json").write_text(json.dumps(status, indent=2)+"\n")
    print(json.dumps({k:v for k,v in status.items() if k != "checks"}))
    assert all(checks.values()), [key for key, ok in checks.items() if not ok]


if __name__ == "__main__":
    main()
