#!/usr/bin/env python3
"""Package only accepted corrected-source scalars and their completion logs.

This creates a separate local dataset. It does not alter campaign data, the
compact source distribution, or any external repository/cloud destination.
"""

import argparse
import hashlib
import json
import tarfile
from datetime import datetime, timezone
from pathlib import Path


PROJECT = Path(__file__).resolve().parents[1]
CAMPAIGN = PROJECT / "results/fidelity-ablation-corrected-v0.2.0-dev"
LIMIT_MARKER = "Simulation time limit reached -- at t=1036800s"


def digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            value.update(block)
    return value.hexdigest()


def accepted_files():
    status = json.loads((CAMPAIGN / "state/status.json").read_text())
    if (status["pass"], status["fail"], status["total"]) != (900, 0, 900):
        raise ValueError("The corrected campaign is not 900/900 accepted")
    receipts = sorted((CAMPAIGN / "state/accepted").glob("*.ok"))
    if len(receipts) != 900:
        raise ValueError("Expected exactly 900 acceptance receipts")
    files = [CAMPAIGN / "state/campaign-manifest.json",
             CAMPAIGN / "state/status.json", *receipts]
    scalars, logs, identities = set(), set(), set()
    for receipt in receipts:
        fields = dict(line.split("=", 1) for line in receipt.read_text().splitlines())
        config, run, scalar_name = fields["configuration"], int(fields["run"]), fields["scalar"]
        identity = (config, run)
        if identity in identities or run not in range(50):
            raise ValueError(f"Duplicate or invalid run identity: {receipt}")
        identities.add(identity)
        if Path(scalar_name).name != scalar_name:
            raise ValueError(f"Unsafe scalar name: {scalar_name}")
        scalar = CAMPAIGN / "scalars" / scalar_name
        log = CAMPAIGN / "logs" / f"{config}-run{run}.log"
        if not scalar.is_file() or not log.is_file() or scalar.stat().st_size == 0:
            raise ValueError(f"Missing scalar or log for {identity}")
        if LIMIT_MARKER not in log.read_text(errors="replace"):
            raise ValueError(f"Completion marker missing for {identity}")
        scalars.add(scalar)
        logs.add(log)
    if (len(scalars), len(logs)) != (900, 900):
        raise ValueError("Accepted receipts do not select 900 distinct scalar/log pairs")
    if (set((CAMPAIGN / "scalars").glob("*.sca")) != scalars
            or set((CAMPAIGN / "logs").glob("*.log")) != logs):
        raise ValueError("Raw result directory differs from the accepted selection")
    return sorted(files + list(scalars) + list(logs))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--output-dir", required=True, type=Path)
    args = parser.parse_args()
    output = args.output_dir.resolve()
    if output.exists():
        raise SystemExit(f"refusing to overwrite existing output: {output}")
    files = accepted_files()
    output.mkdir(parents=True)
    inventory = []
    for index, path in enumerate(files, 1):
        inventory.append({"path": path.relative_to(CAMPAIGN).as_posix(),
                          "size": path.stat().st_size, "sha256": digest(path)})
        if index % 100 == 0:
            print(f"hashed {index}/{len(files)} files", flush=True)
    manifest = {
        "artifact": "Enhanced FLoRa corrected 0.2.0-dev accepted raw data",
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "accepted_runs": 900,
        "scalar_files": 900,
        "completion_logs": 900,
        "campaign_manifest_sha256": digest(CAMPAIGN / "state/campaign-manifest.json"),
        "files": inventory,
        "scope": "Accepted corrected F0--F5 scalars and logs only; not official FLoRa 1.1",
    }
    metadata = output / "raw-data-manifest.json"
    metadata.write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n")
    archive = output / "enhanced-flora-corrected-0.2.0-dev-accepted-raw.tar.gz"
    with tarfile.open(archive, mode="w:gz", compresslevel=1) as stream:
        for index, path in enumerate(files, 1):
            name = "raw-corrected-0.2.0-dev/" + path.relative_to(CAMPAIGN).as_posix()
            info = stream.gettarinfo(str(path), arcname=name)
            info.mtime = 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            with path.open("rb") as source:
                stream.addfile(info, source)
            if index % 100 == 0:
                print(f"archived {index}/{len(files)} files", flush=True)
    archive_hash = digest(archive)
    (output / f"{archive.name}.sha256").write_text(f"{archive_hash}  {archive.name}\n")
    print(json.dumps({"archive": str(archive), "sha256": archive_hash,
                      "files": len(files), "bytes": archive.stat().st_size}, indent=2))


if __name__ == "__main__":
    main()
