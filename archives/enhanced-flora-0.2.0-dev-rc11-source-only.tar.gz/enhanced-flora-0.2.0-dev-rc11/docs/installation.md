# Installation and reproducible build

## Validated research environment

The completed Enhanced FLoRa campaigns were built with:

- OMNeT++ `6.0pre11`, build `210423-26668997ef`, Clang 10 release mode;
- INET `4.3.2`, local version string `inet-4.3.2-23d74062fc`;
- Enhanced FLoRa as a sibling of INET under the OMNeT++ `samples/` directory.

These values describe the validated artifact; they are not a promise that no
other compatible version can work. Results from a rebuilt or upgraded stack
must pass the equivalence suite before they are pooled with released data.

Recorded local binary hashes for the completed campaign environment are:

| Artifact | SHA-256 |
|---|---|
| `opp_run` | `847c152f98f6d19c1c86f641aba119e77d1ad6af8e21f50d5b67945cfd985487` |
| `libINET.so` | `d381b7f7fb1c58e966de9f330050548cc3b4bd70817ef2d9498baef678646f23` |
| corrected-campaign `libflora.so` | `a83fbfd8ee4c9557fd1b0491fb390ceaf880eeed1bd7cbd4d95108cee4bbfcb5` |

## Layout

Place the distribution as `samples/flora` and INET as `samples/inet` inside an
OMNeT++ 6.0pre11 installation. Initialize the OMNeT++ environment before the
build.

```sh
cd /path/to/omnetpp-6.0pre11
. setenv
cd samples/inet
make makefiles
make MODE=release -j2
cd ../flora
make makefiles
make MODE=release -j2
```

The small job count is a conservative build default, not the simulation
parallelism used by campaigns.

## Validation and isolated reruns

From the extracted distribution root, first verify the immutable evidence.
The MAC diagnostic builds a disposable instrumented source copy:

```sh
python3 tools/verify_corrected_release.py .
python3 tests/run_mac_one_send_regression.py . \
  --inet-dir ../inet --output-dir /tmp/flora-mac-check-unique
```

To inspect a new F0--F5 run plan without touching the frozen paper data:

```sh
python3 tools/rerun_corrected_release.py \
  --inet-dir ../inet --output-dir /tmp/flora-new-campaign-unique \
  --stages F5 --populations static --nodes 100 --repetitions 1 --dry-run
```

Remove `--dry-run` to execute. The default horizon is 12 simulated days;
the paper configuration has five repetitions per cell. The runner writes only
to the new external output directory and accepts `--resume` after interruption.
It records the rebuilt library and dependency hashes. A new build is a new
evidence identity, not bit-equivalent to the frozen paper campaign by fiat.
Do not run the historical hardwired campaign runner inside this distribution
or copy a compiled library from another OMNeT++/INET environment.

## Official FLoRa 1.1 reference

The source-faithful official reference is a separate artifact pinned to FLoRa
1.1.0, OMNeT++ 6.0 final, and INET 4.4.0. It must not load the Enhanced library
or reuse this build directory.
