// SPDX-License-Identifier: LGPL-3.0-or-later
#pragma once
#include <cmath>
#include <omnetpp.h>
#include "inet/common/packet/Packet.h"
#include "inet/physicallayer/wireless/common/contract/packetlevel/ITransmission.h"

namespace flora { namespace audit {
bool enabled();
void packet(const omnetpp::cComponent *component, const char *event,
            const inet::Packet *packet, const char *reason = "",
            double value1 = NAN, double value2 = NAN,
            double value3 = NAN, double value4 = NAN,
            long sequence = -1, omnetpp::simtime_t start = -1,
            omnetpp::simtime_t end = -1);
void generated(const omnetpp::cComponent *component, const inet::Packet *packet,
               long sequence, int sf, double powerDbm, double frequencyHz);
void phy(const omnetpp::cComponent *component, const char *event,
         const inet::physicallayer::ITransmission *transmission,
         const char *reason = "");
void state(const omnetpp::cComponent *component, const char *event,
           const inet::Packet *packet, int previousSf, int nextSf,
           double previousPower, double nextPower);
void energy(const omnetpp::cComponent *component,
            omnetpp::simtime_t start, omnetpp::simtime_t end,
            double tx, double rx, double idle, double sleep, double other);
} }
