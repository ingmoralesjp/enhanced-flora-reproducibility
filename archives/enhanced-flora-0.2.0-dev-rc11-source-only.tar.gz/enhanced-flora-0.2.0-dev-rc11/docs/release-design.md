# Repository and research-compendium design

## Repository contents

The public repository will contain:

- LGPL-3.0 license and prominent attribution to official FLoRa;
- clean active `src/` sources, `.msg` inputs, NED files, and generated message
  files required by the documented build;
- minimal build metadata and pinned dependency versions/hashes;
- canonical examples for smoke tests and the F0--F5 ablation;
- formula, component, integration, and campaign-audit tests;
- resumable runners and analysis/figure generators;
- summarized run-level data used by every table and figure;
- paper sources, change inventory, migration guide, citation metadata, and
  machine-readable provenance/manifests.

## Contents deliberately excluded from Git

- `src_Con_Mejoras/` historical alternatives;
- `*.old`, ad-hoc backups, editor state, logs, compiled libraries, and `out*`;
- OMNeT++, INET, or other third-party binaries;
- the approximately 54 GB working result tree and recovery duplicates.

Raw accepted scalars will be published as a separately versioned dataset or
release asset. The repository will pin that artifact by cryptographic hashes
and will retain the complete summary tables needed to rebuild the paper.

## Release acceptance gates

1. **Boundary:** upstream commit, Enhanced source snapshot, toolchain, and every
   experiment config have immutable identities.
2. **Build:** a clean release build succeeds from documented dependencies.
3. **Formula tests:** propagation, noise, SNR threshold, ToA, duty holdoff, and
   energy vectors pass independently.
4. **Protocol tests:** ADR recovery, RX1/RX2, radio/MAC ordering, channel choice,
   deduplication, and warm-up semantics pass.
5. **Campaign audit:** the corrected-source F0--F5 900-run matrix is separately
   rechecked before export; historical `0.1.0-dev` results are not relabeled.
6. **Official reference:** pristine failures remain preserved and all attempted
   100--1000-node cells receive independent success/failure accounting. No
   compatibility-fork result is relabeled pristine; missing cells are not
   imputed or used for survivor-only performance claims.
7. **Paper regeneration:** one documented command rebuilds tables, vector
   figures, references, and the final PDF from released data.
8. **Archive:** source and data archives receive SHA-256 manifests and versioned
   release notes; no claim depends on an untracked local file.

## Claim discipline

The release may be described as an audited, tested, reproducible extension of
FLoRa 1.1. It must not be described as an official upstream successor, as a
field-validated radio model, or as proof that every correction improves PDR.
The ablation demonstrates that some corrections are neutral in the tested
region and that fidelity can reduce apparent performance by removing optimistic
assumptions.
