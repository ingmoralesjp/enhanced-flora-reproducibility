#!/usr/bin/env python3
"""Portable native component invocation with explicit dependency paths."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

HERE=Path(__file__).resolve().parent

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--source-root',type=Path,default=HERE/'testbed/flora')
    p.add_argument('--omnet-dir',type=Path,required=True)
    p.add_argument('--inet-dir',type=Path,required=True)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--build',action='store_true');p.add_argument('--jobs',type=int,default=8)
    a=p.parse_args();root=a.source_root.resolve();omnet=a.omnet_dir.resolve();inet=a.inet_dir.resolve();out=a.output.resolve()
    if out.exists():p.error('Use a fresh output directory')
    subprocess.run([sys.executable,str(HERE/'component_oracle.py'),'prepare',str(out)],check=True)
    env=os.environ.copy();env['PATH']=str(omnet/'bin')+os.pathsep+env.get('PATH','')
    for key in ('FLORA_AUDIT_TRACE','FLORA_AUDIT_RUN','FLORA_AUDIT_PROFILE'):env.pop(key,None)
    commands=[]
    def run(cmd,cwd,log):
        commands.append({'command':cmd,'cwd':str(cwd)})
        with log.open('x') as f:subprocess.run(cmd,cwd=cwd,env=env,stdout=f,stderr=subprocess.STDOUT,check=True)
    if a.build:
        run(['make','makefiles'],root,out/'makefiles.log')
        run(['make','MODE=release',f'INET_PROJ={inet}',f'-j{a.jobs}'],root,out/'build.log')
    ini=out/'component.ini'
    ini.write_text(f'''include {root/'simulations/examples/fidelity-ablation.ini'}

[Config ComponentAuditPortable]
extends = FidelityF5EnhancedStatic
network = flora.ComponentAuditNetwork
repeat = 1
**.numberOfNodes = 1
sim-time-limit = 2000s
warmup-period = 2s
**.numberOfPacketsToSend = 0
**.audit.outputFile = "{out/'component-observed.csv'}"
**.schedulerProbe.outputFile = "{out/'scheduler-observed.csv'}"
**.schedulerProbe.attempts = "{out/'scheduler-input.csv'}"
**.cmdenv-log-level = off
''')
    run([str(omnet/'bin/opp_run'),'-u','Cmdenv','-c','ComponentAuditPortable','-r','0','-n',f'{root/"src"}:{root/"simulations"}:{inet/"src"}','-l',str(root/'src/libflora.so'),'-l',str(inet/'src/libINET.so'),f'--output-scalar-file={out/"run.sca"}',str(ini)],root/'simulations/examples',out/'run.log')
    run([sys.executable,str(HERE/'component_oracle.py'),'analyze',str(out)],HERE,out/'oracle.log')
    status=json.loads((out/'status.json').read_text())
    receipt={'status':status['status'],'commands':commands,'hashes':{str(f):hashlib.sha256(f.read_bytes()).hexdigest() for f in (root/'src/libflora.so',inet/'src/libINET.so',omnet/'bin/opp_run',HERE/'component_oracle.py',HERE/'run_component_suite.py')}}
    (out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
    return status['status']!='PASS'

if __name__=='__main__':raise SystemExit(main())
