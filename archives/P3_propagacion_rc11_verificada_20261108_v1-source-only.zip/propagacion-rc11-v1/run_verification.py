#!/usr/bin/env python3
"""Create a disposable private native build; refuse every existing output path."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tarfile
import time
import design

HERE=Path(__file__).resolve().parent
ARCHIVE_SHA="544414b2c6d0f9a3954154f4bb06289b646c0f3a09326f3d0d50953ea9cb6bd0"


def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda:stream.read(1024*1024),b""):h.update(block)
    return h.hexdigest()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument("--source-archive",type=Path,required=True)
    parser.add_argument("--omnet-dir",type=Path,required=True)
    parser.add_argument("--inet-dir",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--protected-root",type=Path)
    args=parser.parse_args()
    source=args.source_archive.resolve();omnet=args.omnet_dir.resolve();inet=args.inet_dir.resolve();out=args.output.resolve()
    assert sha(source)==ARCHIVE_SHA
    if out.exists():parser.error("Refusing existing output; choose a fresh version/path")
    protected=[source,omnet/"bin/opp_run",inet/"src/libINET.so"]
    if args.protected_root:
        parent=args.protected_root.resolve();manifest=json.loads((parent/"MANIFEST.json").read_text())
        protected += [parent/name for name in manifest["files"]]
    before={str(path):sha(path) for path in protected}
    out.mkdir(parents=True)
    before_path=out/"protected-inputs-before.json";before_path.write_text(json.dumps(before,indent=2)+"\n")
    start=time.monotonic()
    recipe=dict(version="p3-propagation-verification-v1",declared_before_native_execution_utc=datetime.now(timezone.utc).isoformat(),source_archive_sha256=ARCHIVE_SHA,cases=design.cases(),seeds=design.SEEDS,samples_per_block=design.SAMPLES_PER_BLOCK,family_alpha=design.FAMILY_ALPHA,numeric_relative_tolerance=design.RELATIVE_TOLERANCE,attenuation_absolute_floor=design.ATTENUATION_ABSOLUTE_FLOOR,range_absolute_floor_m=design.RANGE_ABSOLUTE_FLOOR_M,references=design.REFERENCES,
        interpretation="Reference-calculation conformance; no hardware calibration, no MAC changes, no new PDR or energy estimates; below-d0 cases test archived extrapolation, not the ns-3 below-d0 clamp")
    (out/"DESIGN.json").write_text(json.dumps(recipe,indent=2)+"\n")
    (out/"REFERENCES.json").write_text(json.dumps(design.REFERENCES,indent=2)+"\n")
    work=out/"work";src=work/"src";build=work/"build";build.mkdir(parents=True)
    copied={}
    with tarfile.open(source) as archive:
        for name in ("src/package.ned","src/LoRaPhy/LoRaLogNormalShadowing.cc","src/LoRaPhy/LoRaLogNormalShadowing.h","src/LoRaPhy/LoRaLogNormalShadowing.ned"):
            data=archive.extractfile("enhanced-flora-0.2.0-dev-rc11/"+name).read()
            target=work/name;target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(data)
            copied[name]="sha256:"+sha(target)
    (out/"unmodified-source-hashes.json").write_text(json.dumps(copied,indent=2)+"\n")
    for name in ("PropagationProbe.cc","PropagationProbe.ned"):shutil.copy2(HERE/"harness"/name,src/name)
    inputfile=out/"native-inputs.txt"
    fields=("case_id","group","d0_m","gamma","sigma_dB","friis","reference_loss_dB","reference_frequency_Hz","reference_speed_mps","tx_gain_dBi","rx_gain_dBi","system_loss_dB","distance_m","argument_frequency_Hz","argument_speed_mps","tx_power_dBm")
    inputfile.write_text("".join(" ".join(str(row[key]) for key in fields)+"\n" for row in recipe["cases"]))
    env=os.environ.copy();env["PATH"]=str(omnet/"bin")+os.pathsep+env.get("PATH","")
    env["LD_LIBRARY_PATH"]=os.pathsep.join([str(omnet/"lib"),str(inet/"src"),env.get("LD_LIBRARY_PATH","")])
    commands=[]
    def checked(command,cwd,log):
        began=time.monotonic()
        with log.open("x") as stream:
            result=subprocess.run(command,cwd=cwd,env=env,stdout=stream,stderr=subprocess.STDOUT)
        commands.append(dict(command=command,cwd=str(cwd),returncode=result.returncode,wall_seconds=time.monotonic()-began,log=str(log.relative_to(out))))
        if result.returncode:raise RuntimeError("Command failed; inspect preserved "+str(log))
    compiler=shutil.which("clang++",path=env["PATH"])
    assert compiler
    version=subprocess.check_output([compiler,"--version"],text=True)
    (out/"compiler-version.txt").write_text(version)
    library=build/"libp3propagation.so"
    command=[compiler,"-std=c++14","-O2","-DNDEBUG","-fPIC","-shared","-DINET_IMPORT","-I"+str(omnet/"include"),"-I"+str(inet/"src"),"-I"+str(src),str(src/"LoRaPhy/LoRaLogNormalShadowing.cc"),str(src/"PropagationProbe.cc"),"-L"+str(inet/"src"),"-L"+str(omnet/"lib"),"-Wl,-rpath,"+str(omnet/"lib"),"-Wl,-rpath,"+str(inet/"src"),"-lINET","-loppsim","-loppenvir","-loppcommon","-loppnedxml","-o",str(library)]
    try:
        checked(command,work,out/"build.log")
        native=out/"native";native.mkdir()
        for seed in design.SEEDS:
            run=native/("seed-%d"%seed);run.mkdir()
            ini=run/"run.ini"
            ini.write_text('[General]\nnetwork=flora.PropagationVerification\nrng-class="cMersenneTwister"\nnum-rngs=1\nseed-set=%d\nsim-time-limit=1s\ncmdenv-express-mode=true\n**.scalar-recording=true\n**.vector-recording=false\n*.probe.runDeterministic=%s\n*.probe.samplesPerBlock=%d\n*.probe.inputFile="%s"\n*.probe.outputFile="%s"\n*.probe.samplesFile="%s"\n' % (seed,"true" if seed==0 else "false",design.SAMPLES_PER_BLOCK,inputfile,run/"observed.csv",run/"samples.csv"))
            command=[str(omnet/"bin/opp_run"),"-u","Cmdenv","-r","0","-n",str(src)+os.pathsep+str(inet/"src"),"-l",str(inet/"src/libINET.so"),"-l",str(library),"--output-scalar-file="+str(run/"run.sca"),str(ini)]
            checked(command,run,run/"run.log")
            print("Native propagation seed",seed,"completed",flush=True)
        checked([sys.executable,str(HERE/"oracle.py"),str(out)],HERE,out/"oracle.log")
        status=json.loads((out/"analysis/status.json").read_text())
        assert status["status"]=="PASS"
    finally:
        after={str(path):sha(path) for path in protected}
        same=before==after
        receipt=dict(status="PASS" if same and (out/"analysis/status.json").is_file() and json.loads((out/"analysis/status.json").read_text())["status"]=="PASS" else "FAIL",commands=commands,source_hashes=copied,protected_unchanged=same,protected_files=len(before),total_wall_seconds=time.monotonic()-start,plugin_sha256=sha(library) if library.exists() else None,runner_sha256=sha(Path(__file__)),oracle_sha256=sha(HERE/"oracle.py"),design_sha256=sha(HERE/"design.py"))
        (out/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
        (out/"protected-inputs-after.json").write_text(json.dumps(after,indent=2)+"\n")
        if not same:raise RuntimeError("Protected input changed; stop and investigate")
    print(json.dumps({key:value for key,value in receipt.items() if key!="commands"},indent=2))


if __name__=="__main__":main()
