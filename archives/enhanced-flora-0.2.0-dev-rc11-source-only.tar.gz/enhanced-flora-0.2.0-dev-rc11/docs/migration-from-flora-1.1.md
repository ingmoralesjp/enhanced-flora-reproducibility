# Migration from official FLoRa 1.1

Enhanced FLoRa changes scientific behavior as well as software interfaces.
Migrating an INI file without reviewing these items can silently redefine an
experiment.

## Required review

- **Propagation:** choose whether the log-normal reference loss is fixed or
  Friis-derived; record `d0`, carrier frequency, gains, system loss, exponent,
  and shadowing sigma.
- **Channels:** declare the actual EU868 set and allocation policy rather than
  relying on an inherited fixed frequency.
- **Payload:** distinguish application bytes, position bytes within that payload,
  MAC bytes, and actual on-air bytes used by ToA.
- **Reception:** record bandwidth, noise figure, sensitivity table, and
  SF-specific required-SNR thresholds independently.
- **Traffic:** declare the offered inter-packet process separately from any
  regulatory queue or holdoff. Official FLoRa's SF-conditioned redraw is not
  numerically interchangeable with an unfiltered application clock.
- **Gateway duty cycle:** set the duty fraction explicitly and interpret rejected
  or delayed downlinks using actual packet ToA.
- **Energy:** choose full-run or post-warm-up energy and preserve the matching
  PDR measurement window.
- **Mobility:** select stationary or RandomWaypoint modules in configuration;
  verify radius and trajectory bounds instead of changing source types.
- **Metrics:** use unique application deliveries; do not count gateway copies,
  CSI, heartbeats, or control frames as additional delivered data.
- **Reproducibility:** preserve seed mapping, config identity, simulator horizon,
  warm-up, source/library hashes, and the acceptance receipt for every run.

## Comparison rule

Re-run a small matched case before moving a legacy campaign. An official-1.1
result and an Enhanced result are stack-level observations unless one mechanism
at a time is controlled. The F0--F5 ablation provides the supported causal path;
F0 itself is a recovered Enhanced-lineage baseline, not stock FLoRa 1.1.
