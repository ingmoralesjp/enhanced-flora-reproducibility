# Official FLoRa 1.1 versus corrected-v1 Legacy

This matrix defines what the official-reference experiment can and cannot
show. It compares complete simulator stacks. It is not a one-factor test of
the Legacy ADR algorithm.

## Inputs deliberately matched

- One gateway at the center of a static uniform 15 km disk.
- 100 through 1,000 end devices in steps of 100; ten run-level repetitions.
- Twelve simulated days, two-day warm-up, exponential 1,000 s application
  clock, and 20 application bytes.
- Initial SF uniformly distributed over SF7--SF12, TP over
  `{2,4,6,8,10,12,14}` dBm, and a fixed per-device choice among the three
  mandatory EU868 channels.
- Legacy server method `max`, 15 dB margin, and 20 received frames per ADR
  evaluation.
- Supplied shadowing parameters `d0=1,000 m`, `gamma=2.32`, and `sigma=7.08`.

The random distributions are matched, but runs are not paired. Module
initialization order, bounded draws, OMNeT++ version, and INET version differ.

## Implementations that remain different

| Aspect | Official FLoRa 1.1 reference | Corrected-v1 Legacy | Consequence |
|---|---|---|---|
| Provenance | Official tag `v1.1.0`, commit `51018f8`; OMNeT++ 6.0 final; INET 4.4.0 | Research fork; OMNeT++ 6.0pre11; INET 4.3.2 | The comparison is across stacks, not binary-equivalent executables. |
| Mobility | `LoRaNode` embeds `StationaryMobility`; the app casts to that type | Static or `RandomWaypointMobility` through `IMobility` | Only the static subset is comparable; no official mobile values are imputed. |
| Circular placement | Official app writes `initialX/Y` at initialization; a separate NED adapter only marks those parameters mutable under OMNeT++ 6.0 final | Native corrected node supports the same uniform-disk construction | The adapter enables intended official code; it changes no C++ behavior. |
| Path-loss reference | Hard-coded `PL(d0)=127.41 dB`, regardless of frequency and configured `d0` | Friis reference at `d0`, 868 MHz, then the same gamma/shadowing form | At 1 km, Friis is about 91.21 dB: a roughly 36.20 dB baseline gap that can dominate PDR. |
| Application bytes versus airtime | The app sends the configured 20 B, but the PHY duration formula hard-codes 20 B for an ED and 15 B for a GW | Semtech-style airtime uses the actual on-air packet length after removing only the simulator preamble | Official duration ignores actual MAC/application composition; corrected duration includes it. |
| End-device pacing | Each new exponential interval is redrawn until it exceeds an SF-specific constant (7.808--171.213 s) | The common application clock is scheduled directly; corrected-v1 has no ED per-subband queue | Offered load becomes SF-dependent in stock FLoRa. This is explicitly corrected only in the future corrected-v2 design. |
| Gateway duty holdoff | Fixed SF-specific constants (0.61696--14.49984 s), independent of the actual downlink packet | Actual downlink time on air divided by configured duty cycle (1% in v1) | Downlink acceptance and gateway deaf time differ. |
| Noise and decoding | Receiver sensitivity values are also used as background-noise power; no separate required-SNR success gate | Thermal `kTB` plus noise figure, sensitivity gate, and SF-specific required-SNR gate | Link admission and collision/SNIR outcomes differ even under identical positions. |
| ADR core | Fixed 20-frame history, `max` or `avg`, 15 dB margin, 3 dB steps, ACK limit/delay 64/32 | The Legacy arm uses the same high-level 20/max/15/3 and 64/32 policy in a refactored, instrumented server | Similar policy does not make the surrounding execution semantics identical. |
| Energy endpoint | `totalEnergyConsumed` covers the full simulation, including warm-up | Measurement-window radio energy; candidate arms may add explicit positioning energy | Official energy is diagnostic only and is not pooled or contrasted as the same endpoint. |
| Output evidence | PDR, sent packets, final SF/TP, ADR commands, per-SF receptions, native energy | In addition: initial state, SF residence, per-device PDR, channel counters, airtime and policy diagnostics | Only common, semantically aligned fields are compared. |

## Interpretation rule

If official and corrected Legacy PDR differ, the result establishes that
“Legacy in corrected FLoRa” is not numerically interchangeable with stock
FLoRa 1.1 in this 15 km testbed. It does **not** establish that refactoring the
ADR rule caused the difference. The path-loss reference is the leading
mechanistic explanation and must be reported before airtime, pacing,
duty-cycle, noise, or ADR details.

A future bridge sensitivity may load the official ADR modules with an explicit
Friis-anchored log-normal path-loss adapter. Such a run must be labeled as a
hybrid sensitivity, never as stock FLoRa 1.1, and must remain separate from
both result sets above.
