# Source-to-claim trace for the corrected platform manuscript

This trace belongs to Enhanced FLoRa `0.2.0-dev`. Historical `0.1.0-dev`
results and the pristine official FLoRa 1.1 reference are separate identities.
Paths below are relative to the corrected distribution root.

| Paper claim | Source/configuration | Released evidence | Regeneration or check | Limit |
|---|---|---|---|---|
| Six cumulative F0--F5 stages; 100--1000 devices, three populations, five paired repetitions | `src/`, `simulations/examples/fidelity-ablation.ini`, `simulations/examples/Analisis-fidelity-ablation.ini` | `experiments/enhanced-flora-platform/results/fidelity-ablation-corrected-v0.2.0-dev/state/campaign-manifest.json`, 900 `.ok` receipts, `analysis/run-metrics.csv` | `tools/verify_corrected_release.py`; `analysis/generate_fidelity_ablation_paper_artifacts.py` | Applies to one gateway and the declared 12-day scenario. |
| F3 airtime and F4 gateway-duty corrections materially alter PDR and energy per delivered uplink | `src/LoRaPhy/LoRaTransmitter.cc`, `src/LoRa/LoRaGWMac.cc`, F0--F5 switches in the experiment INI | Corrected `analysis/paired-contrasts-ci95.csv` and `analysis/summary-ci95.csv`; paper tables/figures under `docs/enhanced-flora-platform-paper/corrected-v0.2.0-dev/` | Regenerate from compact corrected CSVs with `analysis/generate_fidelity_ablation_paper_artifacts.py` | Within-source paired contrast, not a field-validation claim. |
| MAC reentry is corrected in the evaluated source; historical optimistic results are not pooled | `src/LoRa/LoRaMac.cc`, `src/LoRa/LoRaRadio.cc`, `src/LoRa/LoRaRadio.h` | Frozen source hashes in corrected `state/campaign-manifest.json`; `docs/change-inventory.md` EF-05; `tests/evidence/mac-one-send-rc4.json` | Compare packaged source hashes with the campaign manifest; rerun `tests/run_mac_one_send_regression.py` with its diagnostic patch | The earlier `0.1.0-dev` matrix is provenance, not corrected evidence; the ten short instrumented paths are not a full-horizon proof. |
| Official FLoRa 1.1 static survey resolved 100 attempts, with 92 accepted and eight failures | `evidence/official-flora-1.1/official-legacy.ini` and separate upstream manifest/toolchain | `official-run-level-n1000.csv`, `official-failures-n1000.csv`, `compact-provenance-n1000.json`, `survey-status.json` | `analysis/regenerate_official_reference.py` reproduces the ten-density table and figure from compact per-run data | Failed runs have no PDR; accepted-run means at failure-prone densities are conditional on completion. |
| Official, corrected F0, and corrected F5 static PDR are shown together; the arithmetic F5-official gap is 2.13 points at 1000 devices | Both distinct experiment configurations and source identities | Official compact run-level data plus corrected F0/F5 rows in `analysis/run-metrics.csv`; `docs/enhanced-flora-platform-paper/official-reference/cross-stack-f0-f5.csv` | `analysis/generate_cross_stack_context.py`; `tools/verify_corrected_release.py` | F0/F5 are internal paired treatments; official is an independent, completion-conditional stack. No cross-stack causal inference. |
| Toolchains differ | `docs/installation.md`, `evidence/official-flora-1.1/TOOLCHAIN.md` | Hashes and version records in manifests | Verify source and configuration hashes before reuse | No common-toolchain bridge has been run; do not pool seeds or claim bit equivalence. |
| End-device duty cycle is not evaluated here | F0--F5 experiment INI, `docs/reviewer-claim-matrix.md` | Paper limitations Section 8 | Separate future off/on pilot after paper closure | The 1000-s exponential traffic process is not a device-side duty regulator. |

The older official source-evidence notes shipped under
`evidence/official-flora-1.1/` also discuss a separate corrected-v1 ADR branch.
They are provenance, not the causal basis for this platform paper's F0--F5
claims. Use the table above and the manuscript's source boundary for this
release.
